import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContentService } from 'src/app/core/services/content.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  newsFeed: any[] = [];
  idNeighborhoodBoard: number = 0; // Inicialización por defecto

  constructor(
    private contentService: ContentService,
    private router: Router
  ) { }

  ngOnInit() {
    const userData = localStorage.getItem('userData');
    if (userData) {
      const parsedData = JSON.parse(userData);
      this.idNeighborhoodBoard = parsedData.id_Neighborhood_Board;
      this.loadReportsAll();
    } else {
      console.error('No se encontraron datos de usuario en localStorage');
    }
  }

  loadReportsAll() {
    if (this.idNeighborhoodBoard) {
      this.contentService.getReportsAll(this.idNeighborhoodBoard).subscribe(
        data => {
          this.newsFeed = [...data].sort((a, b) => parseInt(b.id_report, 10) - parseInt(a.id_report, 10));
        },
        error => {
          console.error('Error al obtener los reportes', error);
        }
      );
    } else {
      console.error('No se encontraron datos de usuario en localStorage');
    }
  }

  goToNoticia(idReport: number) {
    this.router.navigate(['/tabs/tab1/noticia', idReport]);
  }
  // Método para refrescar noticias al hacer scroll
  refreshNews(event: any) {
    this.loadReportsAll();
    event.target.complete(); // Finaliza el refresco
  }
}