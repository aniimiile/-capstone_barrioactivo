import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContentService } from 'src/app/core/services/content.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { AlertController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  providers: [DatePipe] // Opción para declarar el provider aquí
})
export class Tab2Page implements OnInit {
  reservationForm!: FormGroup;
  commonAreas: any[] = [];
  availableDays: any[] = [];
  availableHours: any[] = [];
  startHours: string[] = [];
  endHours: string[] = [];
  selectedAreaId!: number;
  selectedDate!: string;
  idNeighborhoodBoard: number | null = null;

  number_hours: number = 0;

  // Este array contendrá las horas bloqueadas tras la consulta
  blockedHours: string[] = [];

  constructor(
    private router: Router,
    private contentService: ContentService,
    private fb: FormBuilder,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private datePipe: DatePipe
  ) {
    // Definición del formulario con los campos necesarios y validaciones
    this.reservationForm = this.fb.group({
      id_neighborhood_board: ['', Validators.required],
      id_common_area: ['', Validators.required],
      rut: ['', Validators.required],
      date_reservation: ['', Validators.required],
      start_hour: ['', Validators.required],
      end_hour: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.initializeForm();
    this.loadNeighborhoodBoardId();
    this.loadCommonAreas();
  }

  initializeForm() {
    this.reservationForm = this.fb.group({
      area: [null, Validators.required],
      day: [null, Validators.required],
      startHour: [null, Validators.required], // Control para la hora de inicio
      endHour: [null, Validators.required]    // Control para la hora de fin
    });
  }

  loadNeighborhoodBoardId() {
    const userData = localStorage.getItem('userData');
    if (userData) {
      this.idNeighborhoodBoard = JSON.parse(userData).id_Neighborhood_Board;
    }
  }

  loadCommonAreas() {
    if (this.idNeighborhoodBoard) {
      this.contentService.getCommonArea(this.idNeighborhoodBoard).subscribe(
        (data) => {
          this.commonAreas = data;
          console.log('Áreas comunes cargadas:', this.commonAreas);
        },
        (error) => {
          console.error('Error al cargar áreas comunes:', error);
        }
      );
    }
  }

  onAreaChange(areaId: number) {
    this.selectedAreaId = areaId;
    this.loadAvailableDays(areaId);
    this.reservationForm.controls['day'].reset();
    this.availableHours = []; // Reinicia las horas disponibles

    const selectedArea = this.commonAreas.find(area => area.id_common_area === areaId);
    this.number_hours = selectedArea ? selectedArea.number_hours : 0;
    console.log('Número máximo de horas permitido:', this.number_hours);
  }

  loadAvailableDays(areaId: number) {
    if (this.idNeighborhoodBoard && areaId) {
      this.contentService.getReservationCommonAreaDates(this.idNeighborhoodBoard, areaId).subscribe(
        (data) => {
          this.availableDays = data;
        },
        (error) => {
          console.error('Error al cargar días disponibles:', error);
        }
      );
    }
  }

  onDateChange(date: string) {
    this.selectedDate = date;
    this.loadAvailableHours(this.selectedAreaId, date);
    this.reservationForm.controls['hour'].reset();
  }

  loadAvailableHours(areaId: number, date: string) {
    if (this.idNeighborhoodBoard && areaId && date) {
      const formattedDate = this.datePipe.transform(date, 'yyyy-MM-dd');
      if (formattedDate) {
        this.contentService.getReservationCommonAreaHours(this.idNeighborhoodBoard, areaId, formattedDate).subscribe(
          (data) => {
            this.startHours = data.map(item => item.startHour);
            this.endHours = data.map(item => item.endHour); // Verifica este punto
            console.log('Horas de inicio:', this.startHours);
            console.log('Horas de término:', this.endHours);
          },
          (error) => {
            console.error('Error al cargar horas disponibles:', error);
          }
        );
      }
    }
  }

  // Método auxiliar para verificar si una hora está bloqueada
  isHourReserved(hour: string): boolean {
    return this.blockedHours.includes(hour);
  }

  onStartHourChange(selectedStartHour: string) {
    const startMinutes = this.convertTimeToMinutes(selectedStartHour);
    const maxReserveMinutes = this.number_hours > 0 ? this.number_hours * 60 : Infinity; // Permitir todas las horas si el valor es 0.

    // Filtra las horas de término para incluir solo las que están dentro del rango permitido.
    const filteredEndHours = this.endHours.filter(endHour => {
      const endMinutes = this.convertTimeToMinutes(endHour);
      console.log(`Comparando: Start (${startMinutes} min) vs End (${endMinutes} min), Max (${maxReserveMinutes} min)`);
      return endMinutes > startMinutes && endMinutes <= startMinutes + maxReserveMinutes;
    });

    this.endHours = filteredEndHours;
    console.log('Horas finales disponibles tras filtro:', this.endHours);

    // Reinicia el campo de endHour en el formulario para forzar una nueva selección.
    this.reservationForm.controls['endHour'].reset();
  }

  // Método auxiliar para convertir una hora en formato "HH:mm" a minutos
  convertTimeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }

  async onSubmit() {
    // Obtener y analizar userData del localStorage
    const userDataString = localStorage.getItem('userData');
    const userData = userDataString ? JSON.parse(userDataString) : null;

    // Validar que userData contenga los valores requeridos
    if (!userData || !userData.rut || !userData.id_Neighborhood_Board) {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'No se pudo obtener la información del usuario. Por favor, inicie sesión de nuevo.',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }

    // Validar que el formulario esté completo y contenga todos los campos necesarios
    if (this.reservationForm.invalid) {
      const alert = await this.alertController.create({
        header: 'Campos incompletos',
        message: 'Por favor, completa todos los campos.',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }

    const reservationData = this.reservationForm.value;
    const numberHours = this.calculateNumberHours(reservationData.startHour, reservationData.endHour);

    const formattedData = {
      id_neighborhood_board: userData.id_Neighborhood_Board,
      id_common_area: reservationData.area,
      rut: userData.rut,
      date_reservation: reservationData.day,
      start_hour: reservationData.startHour,
      end_hour: reservationData.endHour,
      number_hours: numberHours.toString()
    };

    console.log('Datos formateados enviados en la reserva:', formattedData);

    // Mostrar alerta de confirmación
    this.showAlertConfirm('¿Estás seguro de confirmar reserva?', async () => {
      // Mostrar indicador de carga
      const loading = await this.loadingController.create({
        message: 'Reservando área común...',
      });
      await loading.present();

      // Enviar datos de reserva
      this.contentService.sendReservation(formattedData).subscribe(
        async (response) => {
          await loading.dismiss(); // Ocultar el indicador de carga

          const alert = await this.alertController.create({
            header: 'Reserva Exitosa',
            message: 'Tu reserva se realizó con éxito.',
            buttons: ['OK']
          });
          await alert.present();
          this.reservationForm.reset(); // Limpiar el formulario tras éxito
        },
        async (error) => {
          await loading.dismiss(); // Ocultar el indicador de carga

          const alert = await this.alertController.create({
            header: 'Error',
            message: 'Ocurrió un error al enviar la reserva. Por favor, inténtelo de nuevo.',
            buttons: ['OK']
          });
          await alert.present();
          console.error('Error al enviar la reserva', error);
        }
      );
    });
  }

  // Método auxiliar para calcular el número de horas entre startHour y endHour
  calculateNumberHours(startHour: string, endHour: string): number {
    const start = this.convertTimeToMinutes(startHour);
    const end = this.convertTimeToMinutes(endHour);
    const difference = end - start;

    // Devuelve la cantidad de horas (diferencia en minutos dividido por 60)
    return Math.max(0, Math.floor(difference / 60)); // Asegúrate de no devolver un número negativo
  }

  async showAlertConfirm(message: string, onConfirm: () => void) {
    const alert = await this.alertController.create({
      header: 'Confirma la reserva',
      message: message,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            console.log('Reporte cancelado.');
          }
        },
        {
          text: 'Sí',
          handler: () => {
            onConfirm();
          }
        }
      ]
    });
    await alert.present();
  }

  goToHistorial() {
    this.router.navigate(['tabs/tab2/historial']);
  }
}
