import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Camera, CameraResultType } from '@capacitor/camera';
import { Geolocation } from '@capacitor/geolocation';
import { AlertController, Platform } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  constructor(
    private platform: Platform,
    private router: Router,
    private alertController: AlertController
  ) {
    this.requestPermissions();
    this.initializeBackButtonCustomHandler();
  }

  async requestPermissions() {
    try {
      // Solicitar permiso de la cámara
      const cameraPermission = await Camera.requestPermissions();
      console.log('Permiso de cámara:', cameraPermission);

      // Solicitar permiso de geolocalización
      const locationPermission = await Geolocation.requestPermissions();
      console.log('Permiso de ubicación:', locationPermission);

      if (locationPermission.location === 'granted') {
        console.log('Permiso de ubicación concedido');
      } else {
        console.log('Permiso de ubicación no concedido');
      }
    } catch (error) {
      console.error('Error al solicitar permisos:', error);
    }
  }

  initializeBackButtonCustomHandler() {
    this.platform.backButton.subscribeWithPriority(10, async () => {
      const currentRoute = this.router.url;

      // Verificar si estás en una de las tabs
      if (
        currentRoute === '/tabs/tab1' ||
        currentRoute === '/tabs/tab2' ||
        currentRoute === '/tabs/tab3' ||
        currentRoute === '/tabs/tab4' ||
        currentRoute === '/tabs/tab5'
      ) {
        await this.showLogoutConfirmation();
      } else {
        // Dejar que el comportamiento predeterminado del botón "Atrás" ocurra
        window.history.back();
      }
    });
  }

  async showLogoutConfirmation() {
    const alert = await this.alertController.create({
      header: 'Cerrar Sesión',
      message: '¿Seguro que quieres cerrar sesión?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
        },
        {
          text: 'Cerrar Sesión',
          handler: () => {
            this.logout();
          },
        },
      ],
    });

    await alert.present();
  }

  logout() {
    console.log('Cerrando sesión...');
    localStorage.clear();
    this.router.navigate(['/login']).then(() => {
      window.location.reload();
    });
  }
}
