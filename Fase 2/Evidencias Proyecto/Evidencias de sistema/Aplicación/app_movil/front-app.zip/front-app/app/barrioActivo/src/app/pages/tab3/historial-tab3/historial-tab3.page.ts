import { Component, OnInit } from '@angular/core';
import { LoadingController, ModalController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { ContentService } from 'src/app/core/services/content.service';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Component({
  selector: 'app-historial-tab3',
  templateUrl: './historial-tab3.page.html',
  styleUrls: ['./historial-tab3.page.scss'],
})
export class HistorialTab3Page implements OnInit {
  selectedSegment: string = 'emergencias';
  emergencyHistory: any[] = []; // Aquí almacenaremos los datos de emergencias
  reportHistory: any[] = []; // Aquí almacenaremos los datos de reportes
  idNeighborhoodBoard: number = 0; // Inicialización por defecto
  rut: string = ''; // Inicialización por defecto

  isExpanded: boolean = false; // Controla si la descripción está expandida

  constructor(
    private loadingController: LoadingController,
    private modalController: ModalController,
    private contentService: ContentService,
  ) { }

  ngOnInit() {
    this.loadUserData();
    this.loadEmergencyHistory();
    this.loadReportsHistory();
  }

  loadUserData() {
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    this.idNeighborhoodBoard = userData.id_Neighborhood_Board;
    this.rut = userData.rut;
  }

  async loadEmergencyHistory() {
    // Mostrar cargando
    const loading = await this.loadingController.create({
      message: 'Cargando historial...',
      spinner: 'crescent'
    });
    await loading.present();
    if (this.idNeighborhoodBoard && this.rut) {
      this.contentService.getEmergencyHistory(this.idNeighborhoodBoard, this.rut).subscribe(
        data => {
          this.emergencyHistory = data;
          loading.dismiss(); // Ocultar cargando
        },
        error => {
          console.error('Error al obtener el historial de emergencias', error);
        }
      );
    } else {
      console.error('No se encontraron datos de usuario en localStorage');
    }
  }

  loadReportsHistory() {
    if (this.idNeighborhoodBoard && this.rut) {
      this.contentService.getReportsHistory(this.idNeighborhoodBoard, this.rut).subscribe(
        data => {
          this.reportHistory = data.map((report: any) => ({
            ...report,
            url_image: report.url_image && report.url_image !== 'https://capstone-api-core.aniuskaojeda.dev' ? report.url_image : null
          }));
        },
        error => {
          console.error('Error al obtener el historial de reportes', error);
        }
      );
    } else {
      console.error('No se encontraron datos de usuario en localStorage');
    }
  }

  getStatusText(status: string): string {
    switch (status) {
      case 'pending':
        return 'Pendiente';
      case 'approved':
        return 'Aprobado';
      case 'rejected':
        return 'Rechazado';
      case 'disabled':
        return 'Deshabilitado';
      default:
        return 'Desconocido';
    }
  }

  async openImageModal(image: string) {
    const modal = await this.modalController.create({
      component: ModalComponent,
      componentProps: { imageSrc: image },
    });
    await modal.present();
  }

  toggleDescription() {
    this.isExpanded = !this.isExpanded; // Cambia entre expandir y contraer
  }
}