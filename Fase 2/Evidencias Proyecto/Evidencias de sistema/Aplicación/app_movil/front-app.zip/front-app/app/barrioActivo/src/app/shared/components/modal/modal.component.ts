// import { Component, Input } from '@angular/core';
// import { ModalController } from '@ionic/angular';

// @Component({
//   selector: 'app-modal',
//   templateUrl: './modal.component.html',
//   styleUrls: ['./modal.component.scss'],
// })
// export class ModalComponent {
//   @Input() imageSrc!: string;

//   constructor(
//     private modalController: ModalController,
//   ) { }


//   dismissModal() {
//     this.modalController.dismiss();
//   }
// }


import { Component, Input, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import * as Hammer from 'hammerjs';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
})
export class ModalComponent implements AfterViewInit {
  @Input() imageSrc: string = ''; // Imagen que se pasa desde el modal
  @ViewChild('image', { static: false }) imageElement!: ElementRef; // Referencia a la imagen

  private scale = 1; // Escala inicial de la imagen
  private lastPosX = 0; // Posición X
  private lastPosY = 0; // Posición Y
  private isMoving = false; // Bandera para saber si se está moviendo la imagen

  constructor(private modalCtrl: ModalController) { }

  ngAfterViewInit() {
    const hammer = new Hammer(this.imageElement.nativeElement);
    hammer.get('pinch').set({ enable: true });
    hammer.get('pan').set({ enable: true });

    let currentScale = 1; // Escala inicial
    let currentX = 0; // Posición inicial X
    let currentY = 0; // Posición inicial Y

    // Gesto de pellizcar (zoom)
    hammer.on('pinchmove', (event: HammerInput) => {
      // Calcula una escala más fluida
      const newScale = Math.max(1, Math.min(currentScale * event.scale, 4)); // Entre 1x y 4x
      if (newScale !== this.scale) {
        this.scale = newScale;
        this.applyTransform(currentX, currentY);
      }
    });

    // Gesto de pan (desplazamiento)
    hammer.on('panmove', (event: HammerInput) => {
      if (this.scale > 1) {
        currentX = this.lastPosX + event.deltaX;
        currentY = this.lastPosY + event.deltaY;
        this.applyTransform(currentX, currentY);
      }
    });

    // Finaliza el gesto y guarda la posición
    hammer.on('panend', () => {
      this.lastPosX = currentX;
      this.lastPosY = currentY;
    });

    // Reinicia escala cuando se cierra
    hammer.on('pinchend', () => {
      currentScale = this.scale;
    });
  }

  // Aplica la transformación a la imagen
  private applyTransform(x: number, y: number) {
    const image = this.imageElement.nativeElement;

    // Restringe la posición de la imagen para que no salga de los límites
    const maxX = (image.clientWidth * (this.scale - 1)) / 2;
    const maxY = (image.clientHeight * (this.scale - 1)) / 2;

    const boundedX = Math.max(-maxX, Math.min(x, maxX));
    const boundedY = Math.max(-maxY, Math.min(y, maxY));

    // Aplica la transformación
    image.style.transform = `scale(${this.scale}) translate(${boundedX}px, ${boundedY}px)`;
  }


  // Método para cerrar el modal
  closeModal() {
    this.modalCtrl.dismiss();
  }
}