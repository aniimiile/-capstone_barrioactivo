package com.barrioActivo.dev;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
