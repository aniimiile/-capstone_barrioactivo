import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  emergencyEnabled: boolean = false;

  constructor(
    private router: Router,
    private alertController: AlertController
  ) { }

  ngOnInit() {
    // Leer el estado de emergency_enabled desde el localStorage
    const userData = localStorage.getItem('userData');
    if (userData) {
      const parsedUserData = JSON.parse(userData);
      this.emergencyEnabled = parsedUserData.emergency_enabled || false;
    }
  }

  async goToSOS() {
    if (this.emergencyEnabled) {
      this.router.navigate(['tabs/tab3/sos']);
    } else {
      await this.showAlert('Usted no puede emitir emergencias, por favor comunicarse con el administrador');
    }
  }

  goToReporte() {
    this.router.navigate(['tabs/tab3/reporte']);
  }

  goToHistorial() {
    this.router.navigate(['tabs/tab3/historial-tab3']);
  }

  async showAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Aviso',
      message,
      buttons: ['OK']
    });
    await alert.present();
  }
}
