import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/core/services/auth.service';
import { ContentService } from 'src/app/core/services/content.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  userData: any;
  neighborhoodBoardName: string | null = null; // Para almacenar el nombre de la junta de vecinos
  neighborhoodBoardContact: any = null; // Para almacenar los datos de contacto

  constructor(
    private loadingController: LoadingController,
    private authService: AuthService,
    private contentService: ContentService,
  ) { }

  async ngOnInit() {
    const storedUserData = localStorage.getItem('userData');

    if (storedUserData) {
      this.userData = JSON.parse(storedUserData);
      console.log('User Data:', this.userData); // Verifica los datos del usuario
    }

    // Recuperar las juntas de vecinos
    this.authService.fetchNeighborhoodBoards().subscribe(() => {
      this.neighborhoodBoardName = this.authService.getNeighborhoodBoardName(this.userData.id_Neighborhood_Board);
      console.log('Neighborhood Board Name:', this.neighborhoodBoardName); // Verifica el nombre de la junta
    });

    // Llamada a getInfoJuntas para obtener la información de contacto de la junta de vecinos
    // Mostrar cargando
    const loading = await this.loadingController.create({
      message: 'Cargando perfil',
      spinner: 'crescent'
    });
    await loading.present();
    if (this.userData?.id_Neighborhood_Board) {
      this.contentService.getInfoJuntas(this.userData.id_Neighborhood_Board).subscribe(
        data => {
          this.neighborhoodBoardContact = data[0]; // Asumimos que data es un array y obtenemos el primer elemento
          console.log('Neighborhood Board Contact:', this.neighborhoodBoardContact);
          loading.dismiss(); // Ocultar cargando
        },
        error => {
          console.error('Error al obtener los datos de la junta de vecinos', error);
        }
      );
    }
  }

  openEmail(email: string) {
    window.open(`mailto:${email}`, '_blank');
  }

  openWhatsApp(cellphone: string) {
    const whatsappUrl = `https://wa.me/${cellphone}`;
    window.open(whatsappUrl, '_blank');
  }

}