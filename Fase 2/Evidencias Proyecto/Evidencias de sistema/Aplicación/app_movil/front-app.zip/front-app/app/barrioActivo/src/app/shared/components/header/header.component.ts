import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() pageTitle: string = 'BarrioActivo';  // Valor por defecto si no se pasa uno
  @Input() showBackButton: boolean = false;     // Controla si se muestra el botón de retroceso

  constructor(
    private router: Router,
    private navCtrl: NavController,
  ) { }

  ngOnInit() {
    // Detecta si la ruta actual es una de las que necesita mostrar el botón de retroceso
    const currentUrl = this.router.url;
    if (currentUrl.includes('/sos') || currentUrl.includes('/reporte') || currentUrl.includes('/historial-tab3') || currentUrl.includes('/profile') || currentUrl.includes('/noticia') || currentUrl.includes('/historial')) {
      this.showBackButton = true;
    } else {
      this.showBackButton = false;
    }
  }

  goProfile() {
    this.router.navigate(['profile'])
  }
  // Función para retroceder a la página anterior en la pila de navegación
  goBack() {
    const currentUrl = this.router.url;

    // Conditional navigation based on the current path
    if (currentUrl.includes('tab1/noticia')) {
      this.router.navigate(['/tabs/tab1']);
    } else if (currentUrl.includes('tab3/sos') || currentUrl.includes('tab3/reporte') || currentUrl.includes('tab3/historial-tab3')) {
      this.router.navigate(['/tabs/tab3']);
    } else if (currentUrl.includes('tab2/historial')) {
      this.router.navigate(['/tabs/tab2']);
    } else {
      this.navCtrl.back();
    }
  }
}
