import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContentService {

  private urlApi = 'https://capstone-api-core.aniuskaojeda.dev';
  private apiKey = '6VWJulK5Hgth_ZKzsmDsRb-YS';
  private headers = new HttpHeaders({
    'ApiKey': this.apiKey,
    'Content-Type': 'application/json'
  });

  constructor(private http: HttpClient) { }

  // Método para enviar datos de emergencia a la API
  public sendEmergencyData(emergencyData: any): Observable<any> {
    return this.http.post<any>(`${this.urlApi}/app/emergency`, emergencyData, { headers: this.headers });
  }

  public getEmergencyCategory(idNeighborhoodBoard: number): Observable<any> {
    const params = new HttpParams().set('id_neighborhood_board', idNeighborhoodBoard.toString());
    return this.http.get<any>(`${this.urlApi}/app/emergency/category`, { headers: this.headers, params });
  }

  public sendReporteData(reporteData: any): Observable<any> {
    const formData = new FormData();
    formData.append('id_neighborhood_board', reporteData.id_neighborhood_board.toString());
    formData.append('rut', reporteData.rut);
    formData.append('title', reporteData.title);
    formData.append('description', reporteData.description);
    formData.append('image', reporteData.image);

    const headers = new HttpHeaders({ 'ApiKey': this.apiKey });
    return this.http.post<any>(`${this.urlApi}/app/report`, formData, { headers });
  }

  public getEmergencyHistory(idNeighborhoodBoard: number, rut: string): Observable<any> {
    const params = new HttpParams()
      .set('id_neighborhood_board', idNeighborhoodBoard.toString())
      .set('rut', rut);
    return this.http.get<any>(`${this.urlApi}/app/emergency/history`, { headers: this.headers, params });
  }

  public getReportsHistory(idNeighborhoodBoard: number, rut: string): Observable<any> {
    const params = new HttpParams()
      .set('id_neighborhood_board', idNeighborhoodBoard.toString())
      .set('rut', rut);
    return this.http.get<any>(`${this.urlApi}/app/report/history`, { headers: this.headers, params });
  }

  public getReportsAll(idNeighborhoodBoard: number): Observable<any> {
    const params = new HttpParams().set('id_neighborhood_board', idNeighborhoodBoard.toString());
    return this.http.get<any>(`${this.urlApi}/app/reports`, { headers: this.headers, params });
  }

  public getInfoJuntas(idNeighborhoodBoard: number): Observable<any> {
    const params = new HttpParams().set('id_neighborhood_board', idNeighborhoodBoard.toString());
    return this.http.get<any>(`${this.urlApi}/app/neighborhoodBoard`, { headers: this.headers, params });
  }

  public getBankAccount(idNeighborhoodBoard: number): Observable<any> {
    const params = new HttpParams().set('id_neighborhood_board', idNeighborhoodBoard.toString());
    return this.http.get<any>(`${this.urlApi}/app/bankAccount`, { headers: this.headers, params });
  }

  public sendCertificateRequest(certificateData: any): Observable<any> {
    const formData = new FormData();
    formData.append('id_neighborhood_board', certificateData.id_neighborhood_board.toString());
    formData.append('rut', certificateData.rut);
    formData.append('evidence_addres', certificateData.evidence_addres);
    formData.append('evidence_pay', certificateData.evidence_pay);
    formData.append('cellphone', certificateData.cellphone);
    formData.append('addres', certificateData.addres);

    const headers = new HttpHeaders({ 'ApiKey': this.apiKey });
    return this.http.post<any>(`${this.urlApi}/app/certificate`, formData, { headers });
  }

  public getCommonArea(idNeighborhoodBoard: number): Observable<any> {
    const params = new HttpParams().set('id_neighborhood_board', idNeighborhoodBoard.toString());
    return this.http.get<any>(`${this.urlApi}/app/commonArea`, { headers: this.headers, params });
  }

  public getReservationCommonAreaDates(idNeighborhoodBoard: number, idCommonArea: number): Observable<any> {
    const params = new HttpParams()
      .set('id_neighborhood_board', idNeighborhoodBoard.toString())
      .set('id_common_area', idCommonArea.toString());
    return this.http.get<any>(`${this.urlApi}/app/reservationsCommonAreaDates`, { headers: this.headers, params });
  }

  public getReservationCommonAreaHours(idNeighborhoodBoard: number, idCommonArea: number, date: string): Observable<{ startHour: string; endHour: string }[]> {
    const params = new HttpParams()
      .set('id_neighborhood_board', idNeighborhoodBoard.toString())
      .set('id_common_area', idCommonArea.toString())
      .set('date', date);
    return this.http.get<{ startHour: string; endHour: string }[]>(`${this.urlApi}/app/reservationsCommonAreaHours`, { headers: this.headers, params });
  }

  public sendReservation(reservationData: any): Observable<any> {
    const body = {
      id_neighborhood_board: reservationData.id_neighborhood_board,
      id_common_area: reservationData.id_common_area,
      rut: reservationData.rut,
      date_reservation: reservationData.date_reservation,
      start_hour: reservationData.start_hour,
      end_hour: reservationData.end_hour,
      number_hours: reservationData.number_hours,
      request: reservationData.request
    };
    return this.http.post<any>(`${this.urlApi}/app/reservation`, body, { headers: this.headers });
  }

  public getReservationHistory(idNeighborhoodBoard: number, rut: string): Observable<any> {
    const params = new HttpParams()
      .set('id_neighborhood_board', idNeighborhoodBoard.toString())
      .set('rut', rut);
    return this.http.get<any>(`${this.urlApi}/app/reservations`, { headers: this.headers, params });
  }

  public sendReservaDisable(reservaDisableData: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'ApiKey': this.apiKey
    });

    return this.http.post<any>(
      `${this.urlApi}/app/reservation/disable`,
      reservaDisableData,
      { headers }
    );
  }
}
