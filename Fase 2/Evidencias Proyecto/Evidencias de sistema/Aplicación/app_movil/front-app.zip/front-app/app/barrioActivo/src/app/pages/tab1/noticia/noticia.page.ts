import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ContentService } from 'src/app/core/services/content.service';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Component({
  selector: 'app-noticia',
  templateUrl: './noticia.page.html',
  styleUrls: ['./noticia.page.scss'],
})
export class NoticiaPage implements OnInit {
  reportId: number | null = null;
  reportDetails: any; // Cambia el tipo según tu modelo
  allReports: any[] = []; // Arreglo para almacenar todos los reportes

  constructor(
    private route: ActivatedRoute,
    private modalController: ModalController,
    private contentService: ContentService
  ) { }

  ngOnInit() {
    this.reportId = +this.route.snapshot.paramMap.get('id')!;
    console.log('ID del reporte:', this.reportId);

    // Cargar todos los reportes
    this.loadAllReports();
  }

  async openImageModal(image: string) {
    const modal = await this.modalController.create({
      component: ModalComponent,
      componentProps: { imageSrc: image },
    });
    await modal.present();
  }

  loadAllReports() {
    const userData = localStorage.getItem('userData');
    if (userData) {
      const parsedData = JSON.parse(userData);
      const idNeighborhoodBoard = parsedData.id_Neighborhood_Board;

      this.contentService.getReportsAll(idNeighborhoodBoard).subscribe(
        data => {
          this.allReports = data; // Guarda todos los reportes
          this.reportDetails = this.allReports.find(report => report.id_report === this.reportId); // Filtra el reporte específico
          console.log('Detalles del reporte:', this.reportDetails);
        },
        error => {
          console.error('Error al obtener los reportes', error);
        }
      );
    } else {
      console.error('No se encontraron datos de usuario en localStorage');
    }
  }
}