import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController } from '@ionic/angular';
import { ContentService } from 'src/app/core/services/content.service';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page implements OnInit {
  selectedBank: string = 'banco estado'; // Definir como string en lugar de string[]
  bankAccounts: any[] = []; // Array para almacenar los datos de la cuenta bancaria
  idNeighborhoodBoard: number | null = null; // Asignar como null inicialmente

  cellphone: string = '';
  addres: string = '';
  accreditationFile!: File;
  paymentFile!: File;
  accreditationFileName: string = '';
  paymentFileName: string = '';

  constructor(
    private loadingController: LoadingController,
    private alertController: AlertController,
    private contentService: ContentService,
  ) { }

  ngOnInit() {
    // Obtener el ID de la junta de vecinos desde el localStorage
    const userData = localStorage.getItem('userData');
    if (userData) {
      try {
        // Analiza el objeto y asigna el ID si existe
        const parsedUserData = JSON.parse(userData);
        this.idNeighborhoodBoard = parsedUserData.id_Neighborhood_Board || null;
      } catch (error) {
        console.error('Error al analizar los datos de usuario desde el localStorage:', error);
      }
    }

    // Si se ha obtenido un ID válido, llama al servicio
    if (this.idNeighborhoodBoard !== null) {
      this.contentService.getBankAccount(this.idNeighborhoodBoard).subscribe((data: any[]) => {
        // Normaliza los nombres de los bancos en los datos recibidos
        this.bankAccounts = data.map(account => ({
          ...account,
          bank: account.bank.trim()
        }));
      });
    } else {
      console.warn('No se pudo obtener el ID de la junta de vecinos desde el localStorage');
    }
  }

  async onSubmit() {
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    const { rut, id_Neighborhood_Board } = userData;

    // Verificar si los campos están completos
    if (!this.accreditationFile || !this.paymentFile || !this.cellphone || !this.addres) {
      const alert = await this.alertController.create({
        header: 'Campos incompletos',
        message: 'Por favor, completa todos los campos.',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }
    // Validar que el celular tenga exactamente 11 caracteres
    if (this.cellphone.length !== 11) {
      const alert = await this.alertController.create({
        header: 'Número de celular inválido',
        message: 'El número de celular debe tener exactamente 11 caracteres.',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }
    const certificateData = {
      id_neighborhood_board: id_Neighborhood_Board,
      rut: rut,
      evidence_addres: this.accreditationFile,
      evidence_pay: this.paymentFile,
      cellphone: this.cellphone,
      addres: this.addres
    };

    // Mostrar confirmación antes de enviar la solicitud
    this.showAlertConfirm('¿Confirmar la solicitud?', async () => {
      // Mostrar indicador de carga
      const loading = await this.loadingController.create({
        message: 'Enviando Solicitud',
      });
      await loading.present();
      console.log(certificateData);

      // Enviar solicitud
      this.contentService.sendCertificateRequest(certificateData).subscribe(
        async (response) => {
          await loading.dismiss(); // Ocultar indicador de carga

          const alert = await this.alertController.create({
            header: 'Solicitud Enviada',
            message: 'Debes esperar 24 horas para que se habilite tu certificado.',
            buttons: ['OK']
          });
          await alert.present();

          // Limpiar el formulario después de una solicitud exitosa
          this.cellphone = '';
          this.addres = '';
          this.accreditationFile = null as any;
          this.paymentFile = null as any;
          this.accreditationFileName = '';
          this.paymentFileName = '';
        },
        async (error) => {
          await loading.dismiss(); // Ocultar indicador de carga

          const alert = await this.alertController.create({
            header: 'Error',
            message: 'Ocurrió un error al enviar la solicitud, intente nuevamente.',
            buttons: ['OK']
          });
          await alert.present();
          console.error('Error al enviar la solicitud', error);
        }
      );
    });
  }

  async showAlertConfirm(message: string, onConfirm: () => void) {
    const alert = await this.alertController.create({
      header: 'Confirma la solicitud',
      message: message,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            console.log('Solicitud cancelada.');
          }
        },
        {
          text: 'Sí',
          handler: () => {
            onConfirm();
          }
        }
      ]
    });
    await alert.present();
  }

  onFileSelected(event: Event, type: string) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      if (type === 'accreditation') {
        this.accreditationFile = file;
        this.accreditationFileName = file.name; // Asignar nombre del archivo
      } else if (type === 'payment') {
        this.paymentFile = file;
        this.paymentFileName = file.name; // Asignar nombre del archivo
      }
    }
  }
}
