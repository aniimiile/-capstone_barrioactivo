import { Component, OnInit } from '@angular/core';
import { ContentService } from 'src/app/core/services/content.service';
import { AlertController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-historial',
  templateUrl: './historial.page.html',
  styleUrls: ['./historial.page.scss'],
})
export class HistorialPage implements OnInit {
  reservationHistory: any[] = []; // Historial de reservas
  idNeighborhoodBoard: number = 0;
  rut: string = '';

  commonAreas: { [key: string]: string } = {}; // Diccionario de áreas comunes


  constructor(
    private contentService: ContentService,
    private loadingController: LoadingController,
    private alertController: AlertController
  ) { }

  ngOnInit() {
    this.loadUserData();
    this.loadCommonAreas().then(() => this.loadReservationHistory());
  }

  loadUserData() {
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    this.idNeighborhoodBoard = userData.id_Neighborhood_Board;
    this.rut = userData.rut;
  }

  async loadCommonAreas() {
    if (!this.idNeighborhoodBoard) return;

    try {
      const areas = await this.contentService.getCommonArea(this.idNeighborhoodBoard).toPromise();
      this.commonAreas = areas.reduce((acc: any, area: any) => {
        acc[area.id_common_area] = area.name; // Mapear ID al nombre
        return acc;
      }, {});
    } catch (error) {
      console.error('Error al cargar las áreas comunes:', error);
    }
  }

  async loadReservationHistory() {
    // Mostrar cargando
    const loading = await this.loadingController.create({
      message: 'Cargando historial...',
      spinner: 'crescent'
    });
    await loading.present();

    if (this.idNeighborhoodBoard && this.rut) {
      this.contentService.getReservationHistory(this.idNeighborhoodBoard, this.rut).subscribe(
        data => {
          this.reservationHistory = [...data].sort((a, b) => parseInt(b.id_reservation, 10) - parseInt(a.id_reservation, 10));
          loading.dismiss(); // Ocultar cargando
        },
        error => {
          console.error('Error al obtener el historial de reservaciones', error);
        }
      );
    } else {
      console.error('No se encontraron datos de usuario en localStorage');
    }
  }

  async disableReservation(idReservation: number, idCommonArea: string) {
    const alert = await this.alertController.create({
      header: 'Cancelar la reserva',
      message: '¿Estás seguro de que deseas anular esta reserva?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
        },
        {
          text: 'Anular',
          handler: async () => {
            const loading = await this.loadingController.create({
              message: 'Anulando reserva...',
              spinner: 'crescent'
            });
            await loading.present(); // Mostrar el indicador de carga

            const reservaDisableData = {
              id_neighborhood_board: this.idNeighborhoodBoard,
              rut: this.rut,
              id_common_area: idCommonArea,
              id_reservation: idReservation
            };

            console.log('Datos enviados en la solicitud de anulación:', reservaDisableData);

            this.contentService.sendReservaDisable(reservaDisableData).subscribe(
              async (response) => {
                console.log('Reserva anulada:', response);

                // Actualiza la reserva desactivada en el historial
                this.reservationHistory = this.reservationHistory.map((reservation) =>
                  reservation.id_reservation === idReservation
                    ? { ...reservation, enabled: false }
                    : reservation
                );

                // Ocultar el cargando
                await loading.dismiss();

                // Muestra el mensaje de éxito
                const successAlert = await this.alertController.create({
                  header: 'Anulación Exitosa',
                  message: 'La reserva ha sido anulada exitosamente.',
                  buttons: ['OK']
                });
                await successAlert.present();
              },
              async (error) => {
                console.error('Error al anular la reserva:', error);
                // Ocultar el cargando en caso de error
                await loading.dismiss();
                const errorAlert = await this.alertController.create({
                  header: 'Error',
                  message: 'No se pudo anular la reserva. Inténtalo nuevamente.',
                  buttons: ['OK']
                });
                await errorAlert.present();
              }
            );
          },
        },
      ],
    });

    await alert.present();
  }

  // Método para refrescar noticias al hacer scroll
  refreshHistory(event: any) {
    this.loadReservationHistory();
    event.target.complete(); // Finaliza el refresco
  }
}
