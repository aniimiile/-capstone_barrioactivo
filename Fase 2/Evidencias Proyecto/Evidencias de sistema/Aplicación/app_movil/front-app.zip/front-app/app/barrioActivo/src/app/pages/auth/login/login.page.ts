import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  formLogin: FormGroup;
  passwordType: string = 'password';
  passwordIcon: string = 'eye-off-outline';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private authService: AuthService
  ) {
    this.formLogin = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
    });
  }

  ngOnInit() {
    const email = localStorage.getItem('userEmail');
    const password = localStorage.getItem('userPassword');

    if (email && password) {
      this.router.navigate(['/tabs/tab1']);
    }
  }

  async onSubmit() {
    if (this.formLogin.valid) {
      const loading = await this.loadingController.create({
        message: 'Iniciando sesión...',
      });
      await loading.present();

      const { email, password } = this.formLogin.value;
      this.authService.login({ email, password }).subscribe(
        async (response) => {
          await loading.dismiss();

          if (response.status) {
            localStorage.setItem('userEmail', email);
            localStorage.setItem('userPassword', password);

            this.authService.getUserData(email).subscribe(
              async (userData) => {
                localStorage.setItem('userData', JSON.stringify(userData));
                this.router.navigate(['/tabs/tab1']);
              },
              async (error) => {
                console.error('Error al obtener los datos del usuario:', error);
                await this.showAlert('Error al cargar los datos del usuario');
              }
            );
          } else {
            // Mostrar el mensaje recibido desde el backend
            await this.showAlert(response.message || 'Ocurrió un error inesperado');
          }
        },
        async (error) => {
          await loading.dismiss();
          await this.showAlert('Error en el servidor');
          console.error('Error:', error);
        }
      );
    } else {
      await this.showAlert('Por favor, completa todos los campos');
    }
  }


  async showAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Error',
      message: message,
      buttons: ['OK'],
    });

    await alert.present();
  }

  togglePasswordVisibility() {
    if (this.passwordType === 'password') {
      this.passwordType = 'text';
      this.passwordIcon = 'eye-outline';
    } else {
      this.passwordType = 'password';
      this.passwordIcon = 'eye-off-outline';
    }
  }
  async showAlertPassword(message: string) {
    const alert = await this.alertController.create({
      header: 'Restablecer contraseña',
      message: message,
      buttons: ['OK'],
    });

    await alert.present();
  }
  goToPassword() {
    this.showAlertPassword('Favor comunicarse con la administración de su junta de vecinos');
  }

  goToInscripcion() {
    this.router.navigate(['register']);
  }
}
