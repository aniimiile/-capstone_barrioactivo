﻿using Microsoft.AspNetCore.Mvc;
using api_core.Security;
using static api_core.Models.admModel;
using System;
using System.IO;
using System.Threading.Tasks;
using api_core.Services;
using System.Net.NetworkInformation;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using Sprache;
using static api_core.Models.appModel;
namespace api_core.Controllers
{
    [ApiController]
    [Route("[controller]")]
    
    public class admController : ControllerBase
    {
        private readonly ILogger<admController> _logger;
        private readonly admService _admService;

        public admController(ILogger<admController> logger, admService admService)
        {
            _logger = logger;
            _admService = admService;
        }

        [HttpGet("report/update")]
        [ApiKeyAuth]

        public async Task<responseGenericAdm> updateReports(int id_neighborhood_board)
        {
            _logger.LogInformation($"Q: updateReports {id_neighborhood_board} ");
            try
            {


                var result = await _admService.updateReports(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };

            }

        }


        [HttpPost("login")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> login(requestLoginAdm request)
        {
            _logger.LogInformation($"Q: Login: {request.email}");
            try
            {
                var response = await _admService.login(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        [HttpGet("user")]
        [ApiKeyAuth]
        public async Task<UserAdm> getUserInfo(string email)
        {
            _logger.LogInformation($"Q: user: {email} ");
            try
            {


                var result = await _admService.getUserInfo(email);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new UserAdm { };

            }

        }

        [HttpGet("neighborhoods")]
        [ApiKeyAuth]
        public async Task<List<Neighborhood>> getNeighborhoods(int id_neighborhood_board, int id_status)
        {
            try
            {


                var result = await _admService.GetNeighborhood(id_neighborhood_board, id_status);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<Neighborhood> { };

            }

        }

        [HttpPost("user/update")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> userUpdate(UpdateUser request)
        {
            try
            {
                var response = await _admService.userUpdate(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        [HttpPost("user/emergency/update")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> userUpdateEmergencyOption(UpdateUser request)
        {
            try
            {
                var response = await _admService.userUpdateEmergencyOption(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        [HttpGet("reservations")]
        [ApiKeyAuth]
        public async Task<List<reservasList>> getReservations(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.listReservas(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<reservasList> { };

            }

        }

        [HttpGet("commonAreas")]
        [ApiKeyAuth]
        public async Task<List<commonAreaAdm>> getCommonAreas(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.listCommonArea(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<commonAreaAdm> { };

            }

        }

        [HttpPost("commonAreas/create")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> addCommonArea(addCommonArea request)
        {
            try
            {
                var response = await _admService.addCommonArea(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        [HttpPost("commonAreas/daysException/create")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> addDaysException(daysException request)
        {
            try
            {
                var response = await _admService.addDaysException(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        [HttpGet("commonAreas/daysException")]
        [ApiKeyAuth]
        public async Task<List<string>> getDaysException(int id_neighborhood_board, int id_common_area)
        {
            try
            {


                var result = await _admService.getDaysException(id_neighborhood_board, id_common_area);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<string> { };

            }

        }

        [HttpPost("commonAreas/update")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> updateCommonArea(updateCommenArea request)
        {
            try
            {
                var response = await _admService.updateCommonArea(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        [HttpGet("emergency")]
        [ApiKeyAuth]
        public async Task<List<emergencyAdm>> getEmergency(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getEmergency(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<emergencyAdm> { };

            }

        }

        [HttpGet("category")]
        [ApiKeyAuth]
        public async Task<List<emergencyCategory>> getCategories(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getCategories(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<emergencyCategory> { };

            }

        }

        [HttpPost("category/create")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> createCategory(emergencyCategoryCreate request)
        {
            try
            {
                var response = await _admService.createCategory(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        [HttpPost("category/update")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> updateCategory(emergencyCategoryUpdate request)
        {
            try
            {
                var response = await _admService.updateCategory(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        [HttpGet("reports/pending")]
        [ApiKeyAuth]
        public async Task<List<reportsPendding>> getReportsPending(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getReportsPending(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<reportsPendding> { };

            }

        }

        [HttpPost("report/update/status")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> updateReport(reportUpdate request)
        {
            try
            {
                var response = await _admService.updateReport(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        [HttpGet("reports/history")]
        [ApiKeyAuth]
        public async Task<List<reportsHistory>> getReportsHistory(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getReportsHistory(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<reportsHistory> { };

            }

        }

        [HttpGet("bankAccount")]
        [ApiKeyAuth]
        public async Task<List<bankAccountAdm>> getBankAccount(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getBankAccount(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<bankAccountAdm> { };

            }

        }

        [HttpPost("bankAccount/add")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> addBankAccount(bankAccountAdd request)
        {
            try
            {
                var response = await _admService.addBankAccount(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        [HttpGet("certificate/pending")]
        [ApiKeyAuth]
        public async Task<List<certicatePending>> getCertificatePending(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getCertificatePending(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<certicatePending> { };

            }

        }


        [HttpGet("certificate/history")]
        [ApiKeyAuth]
        public async Task<List<certicateHistory>> getCertificateHistory(int id_neighborhood_board)
        {
            try
            {


                var result = await _admService.getCertificateHistory(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<certicateHistory> { };

            }

        }


        [HttpPost("certificate/update")]
        [ApiKeyAuth]
        public async Task<responseGenericAdm> updateCertificate(updateCerticate request)
        {
            try
            {
                var response = await _admService.updateCertificate(request);

                return new responseGenericAdm
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

    }
}
