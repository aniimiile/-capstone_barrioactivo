﻿using Dapper;
using Microsoft.AspNetCore.Identity.Data;
using StackExchange.Redis;
using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics.Eventing.Reader;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Numerics;
using System.Text;
using System.Xml.Linq;
using static api_core.Models.admModel;
using static api_core.Models.appModel;

namespace api_core.Services
{
    public class admService
    {
        private readonly ILogger<admService> _logger;
        private readonly IDbConnection _dbConnection;
        private readonly IConnectionMultiplexer _redis;
        private readonly PdfGeneratorService _pdfGeneratorService;

        public admService(ILogger<admService> logger, IDbConnection dbConnection, IConnectionMultiplexer redis, PdfGeneratorService pdfGeneratorService)
        {
            _logger = logger;
            _dbConnection = dbConnection;
            _redis = redis;
            _pdfGeneratorService = pdfGeneratorService;
        }

        public async Task<responseGenericAdm> login(requestLoginAdm request)
        {
            try
            {
                var sql = @"select u.email, u.password, n.id_status 
                              from users u, user_neighborhood_board n 
                             where u.rut = n.rut 
						       and n.id_type_user in (1, 2)
                               and u.email = @email
                               and u.password = @password
                               and n.enabled";

                var parameters = new { email = request.email, password = request.password };

                var response = await _dbConnection.QueryFirstOrDefaultAsync<Users>(sql, parameters);

                if (response == null)
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "login incorrecto"
                    };
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = true,
                        message = "ok"
                    };
                }
            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = "login incorrecto"
                };
            }
        }
        public async Task<responseGenericAdm> updateReports(int id_neighborhood_board)
        {
            try
            {
                var apiBaseUrl = Environment.GetEnvironmentVariable("API_BASE_URL");

                var sql = @"select r.id_neighborhood_board, r.id_report, r.title, r.description, r.image_path, r.date_report, u.first_name, u.first_surname   
                       from report r, users u
                      where r.rut = u.rut 
                        and r.id_neighborhood_board = @id_neighborhood_board
                        and r.id_status = 2
                      order by r.date_report desc";


                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var reportsList = (await _dbConnection.QueryAsync<reportsAdm>(sql, parameters)).ToList();

                var db = _redis.GetDatabase();

                // Iterar a través de los reportes y manejar la imagen
                foreach (var report in reportsList)
                {
                    if (!string.IsNullOrEmpty(report.image_path))
                    {
                        // Actualizar la URL de la imagen con la variable API_BASE_URL
                        report.image_path = $"{apiBaseUrl}{report.image_path}";
                    }
                    else
                    {
                        // Si no existe el archivo, dejar image_path vacío
                        report.image_path = "";
                    }
                }
                // Guardar todos los reportes en Redis como un solo JSON
                await db.StringSetAsync($"report:{id_neighborhood_board}", System.Text.Json.JsonSerializer.Serialize(reportsList));

                return new responseGenericAdm
                {
                    status = true,
                    message = "Reports updated and saved to Redis successfully."
                };

            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        public async Task<UserAdm> getUserInfo(string email)
        {
            try
            {
                var sql = @"select u.rut, u.first_name, u.second_name, u.first_surname, u.second_surname, u.birthdate, u.email, u.password, u.address, u.cellphone, n.id_neighborhood_board, n.emergency_enabled, n.id_Type_User
                              from users u, user_neighborhood_board n 
                             where u.rut = n.rut
                               and u.email = @email
                               and n.enabled";

                var parameters = new { email = email };

                var response = await _dbConnection.QueryFirstOrDefaultAsync<UserAdm>(sql, parameters);

                return response;


            }
            catch (Exception ex)
            {
                return new UserAdm { };
            }



        }


        public async Task<List<Neighborhood>> GetNeighborhood(int id_neighborhood_board, int id_status)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("API_BASE_URL");

                var sql = @"select u.rut, u.first_name, u.second_name, u.first_surname, u.address_verification_url,  
                            u.second_surname, to_char(u.birthdate, 'YYYY-MM-DD') as birthdate, u.email, u.address, 
                            u.cellphone, n.emergency_enabled,to_char(n.creation_date, 'YYYY-MM-DD') as creation_date, n.enabled, n.id_status
                            from users u, user_neighborhood_board n
                            where u.rut = n.rut
                            and n.id_neighborhood_board = @id_neighborhood_board
                            and n.id_status = @id_status 
                            and n.id_type_user = 3";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, id_status = id_status };

                var response = (await _dbConnection.QueryAsync<Neighborhood>(sql, parameters)).ToList();

                foreach (var neighborhood in response)
                {
                    if (!string.IsNullOrEmpty(neighborhood.address_verification_url))
                    {
                        neighborhood.address_verification_url = $"{url}{neighborhood.address_verification_url}";
                    }
                }

                return response;


            }
            catch (Exception ex)
            {
                return new List<Neighborhood> { };
            }
        }


        public async Task<responseGenericAdm> userUpdate(UpdateUser request)
        {
            try
            {
                bool enabled = false;
                var url = Environment.GetEnvironmentVariable("URL_WHATSAPP");
                var username = Environment.GetEnvironmentVariable("BASIC_AUTH_USERNAME");
                var password = Environment.GetEnvironmentVariable("BASIC_AUTH_PASSWORD");
                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
                string phone = "";
                string message = "";

                if (request.id_status == 2)
                {
                    enabled = true;

                }
                else if (request.id_status == 3)
                {
                    enabled = false;
                }
                else if (request.id_status == 4)
                {
                    enabled = false;
                }

                var sql = @"update user_neighborhood_board
                            set id_status = @id_status, enabled = @enabled, emergency_enabled = @enabled
                            where rut = @rut
                            and id_neighborhood_board = @id_neighborhood_board";


                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    rut = request.rut,
                    id_status = request.id_status,
                    enabled = enabled
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    var sqlPhone = @"select cellphone from users where rut = @rut ";
                    var parametersPhone = new { rut = request.rut };

                    phone = await _dbConnection.QueryFirstOrDefaultAsync<string>(sqlPhone, parametersPhone);

                    var sqlCorreo = @"select name, email from neighborhood_board where id_neighborhood_board = @id_neighborhood_board ";
                    var parametersCorreo = new { id_neighborhood_board = request.id_neighborhood_board };

                    var info = await _dbConnection.QueryFirstOrDefaultAsync<infoJunta>(sqlCorreo, parametersCorreo);



                    if (request.id_status == 2)
                    {
                        message = $"Su solicitud para crear la cuenta en la junta de vecinos '{info.name}' fue aprobado. Puede ingresar en la aplicación.";

                    }
                    else if (request.id_status == 3)
                    {
                        message = $"Su solicitud para crear la cuenta en la junta de vecinos '{info.name}' fue rechazado. Si tiene dudas favor contactarse con el administrador {info.email}.";
                    }
                    else if (request.id_status == 4)
                    {
                        message = $"Su cuenta en la junta de vecino '{info.name}' fue deshabilitada. Si tiene dudas favor contactarse con el administrador {info.email}.";
                    }

                    using (var httpClient = new HttpClient())
                    {
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                        var postData = new
                        {
                            number = phone,
                            message = message
                        };

                        var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                        var response = await httpClient.PostAsync(url, jsonContent);

                        if (!response.IsSuccessStatusCode)
                        {
                            throw new Exception($"Usuario actualizado pero error al enviar mensaje a {phone}: {response.ReasonPhrase}");
                        }
                    }
                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Usuario actualizado correctamente y mensaje enviado correctamente"
                    };
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "usuario no actualizado"
                    };
                }



            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        public async Task<responseGenericAdm> userUpdateEmergencyOption(UpdateUser request)
        {
            try
            {
                bool enabled = false;
                var url = Environment.GetEnvironmentVariable("URL_WHATSAPP");
                var username = Environment.GetEnvironmentVariable("BASIC_AUTH_USERNAME");
                var password = Environment.GetEnvironmentVariable("BASIC_AUTH_PASSWORD");
                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
                string correo = "";
                string phone = "";
                string message = "";

                if (request.id_status == 2)
                {
                    enabled = true;

                }
                else if (request.id_status == 4)
                {
                    enabled = false;
                }

                var sql = @"update user_neighborhood_board
                            set emergency_enabled = @enabled
                            where rut = @rut
                            and id_neighborhood_board = @id_neighborhood_board";


                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    rut = request.rut,
                    enabled = enabled
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    var sqlPhone = @"select cellphone from users where rut = @rut ";
                    var parametersPhone = new { rut = request.rut };

                    phone = await _dbConnection.QueryFirstOrDefaultAsync<string>(sqlPhone, parametersPhone);

                    var sqlCorreo = @"select name, email from neighborhood_board where id_neighborhood_board = @id_neighborhood_board ";
                    var parametersCorreo = new { id_neighborhood_board = request.id_neighborhood_board };

                    var info = await _dbConnection.QueryFirstOrDefaultAsync<infoJunta>(sqlCorreo, parametersCorreo);



                    if (request.id_status == 2)
                    {
                        message = $"La opción de enviar emergencias en la aplicación de Barrio activo para la junta de vecinos '{info.name}' fue habilitado.";

                    }
                    else if (request.id_status == 4)
                    {
                        message = $"La opción de enviar emergencias en la aplicación de Barrio Activo para la junta de vecinos '{info.name}' fue deshabilitado. Si tiene dudas favor contactarse con el administrador {info.email}.";
                    }

                    using (var httpClient = new HttpClient())
                    {
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                        var postData = new
                        {
                            number = phone,
                            message = message
                        };

                        var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                        var response = await httpClient.PostAsync(url, jsonContent);

                        if (!response.IsSuccessStatusCode)
                        {
                            throw new Exception($"Usuario actualizado pero error al enviar mensaje a {phone}: {response.ReasonPhrase}");
                        }
                    }
                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Usuario actualizado correctamente y mensaje enviado correctamente"
                    };
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "usuario no actualizado"
                    };
                }



            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        public async Task<List<reservasList>> listReservas(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select c.name,  r.rut,to_char(r.date_reservation, 'YYYY-MM-DD') as date_reservation, to_char(r.start_hour, 'HH24:MI') as start_hour, to_char(r.end_hour, 'HH24:MI')  as end_hour, r.number_hours 
                            from reservation  r, common_area c 
                            where r.id_neighborhood_board_common_area = c.id_neighborhood_board
                            and r.id_common_area = c.id_common_area
                            and  r.id_neighborhood_board_common_area = @id_neighborhood_board
                            and  r.enabled
                            order by date_reservation desc, name, start_hour";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var response = (await _dbConnection.QueryAsync<reservasList>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)
            {
                return new List<reservasList> { };
            }
        }

        public async Task<List<commonAreaAdm>> listCommonArea(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select  c.id_common_area, c.name, c.addres,  to_char(c.start_time, 'HH24:MI') as start_time,  to_char(c.end_hours, 'HH24:MI') as end_hours, m.number_hours
                            from common_area c, maximum_hours_common_area m 
                            where c.id_neighborhood_board = m.id_neighborhood_board
                            and c.id_common_area = m.id_common_area
                            and c.id_neighborhood_board = @id_neighborhood_board";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var response = (await _dbConnection.QueryAsync<commonAreaAdm>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)
            {
                return new List<commonAreaAdm> { };
            }
        }


        public async Task<responseGenericAdm> addCommonArea(addCommonArea request)
        {
            try
            {
                int id = 0;

                var sql = @"insert into common_area (id_neighborhood_board, name, addres, start_time, end_hours)
                            values (@id_neighborhood_board, @name, @addres, @start_time, @end_hours)";

                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    name = request.name,
                    addres = request.addres,
                    start_time = TimeSpan.Parse(request.start_time),
                    end_hours = TimeSpan.Parse(request.end_hours),
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    var sqlId = "select max(id_common_area)  from common_area where id_neighborhood_board = @id_neighborhood_board";

                    var parametersId = new { id_neighborhood_board = request.id_neighborhood_board };

                    id = await _dbConnection.QueryFirstOrDefaultAsync<int>(sqlId, parametersId);

                    var sqlHour = @"insert into maximum_hours_common_area (id_neighborhood_board, id_common_area, number_hours)
                            values (@id_neighborhood_board, @id_common_area, @number_hours)";

                    var parametersHour = new
                    {
                        id_neighborhood_board = request.id_neighborhood_board,
                        id_common_area = id,
                        number_hours = request.number_hours
                    };

                    var rowsAffectedHour = await _dbConnection.ExecuteAsync(sqlHour, parametersHour);

                    if (rowsAffectedHour > 0)
                    {

                        return new responseGenericAdm
                        {
                            status = true,
                            message = "Area común ingresado correctamente"
                        };
                    }
                    else
                    {

                        return new responseGenericAdm
                        {
                            status = false,
                            message = "Area común no ingresado correctamente"
                        };
                    }

                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "Area común no ingresado"
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        //public async Task<responseGenericAdm> addDaysException(daysException request)
        //{
        //    try
        //    {

        //        var sql = @"insert into exception_of_days (id_neighborhood_board, id_common_area, date_exception)
        //                    values (@id_neighborhood_board, @id_common_area, @date_exception)";

        //        var parameters = new
        //        {
        //            id_neighborhood_board = request.id_neighborhood_board,
        //            id_common_area = request.id_common_area,
        //            date_exception = request.date_exception
        //        };

        //        var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

        //        if (rowsAffected > 0)
        //        {
        //            return new responseGenericAdm
        //            {
        //                status = true,
        //                message = "Fecha de excepción ingresado correctamente"
        //            };
        //        }
        //        else
        //        {
        //            return new responseGenericAdm
        //            {
        //                status = false,
        //                message = "Fecha de excepción no ingresado"
        //            };
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return new responseGenericAdm
        //        {
        //            status = false,
        //            message = $"An error occurred: {ex.Message}"
        //        };
        //    }
        //}

        public async Task<responseGenericAdm> addDaysException(daysException request)
        {
            try
            {

                var url = Environment.GetEnvironmentVariable("URL_WHATSAPP");
                var username = Environment.GetEnvironmentVariable("BASIC_AUTH_USERNAME");
                var password = Environment.GetEnvironmentVariable("BASIC_AUTH_PASSWORD");
                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
                string phone = "";
                string message = "";
                // Insertar la fecha de excepción
                var sqlInsert = @"insert into exception_of_days (id_neighborhood_board, id_common_area, date_exception)
                          values (@id_neighborhood_board, @id_common_area, @date_exception)";
                var parametersInsert = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    id_common_area = request.id_common_area,
                    date_exception = request.date_exception
                };

                var rowsInserted = await _dbConnection.ExecuteAsync(sqlInsert, parametersInsert);

                if (rowsInserted <= 0)
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "No se pudo insertar la fecha de excepción."
                    };
                }

                // Consultar los números de teléfono
                var sqlSelectPhones = @"select u.cellphone
                                from reservation r
                                join users u on r.rut = u.rut
                                where r.id_neighborhood_board_common_area = @id_neighborhood_board
                                and r.id_common_area = @id_common_area
                                and r.date_reservation = @date_exception
                                and r.enabled = true";
                var parametersPhones = new
                {
                    id_neighborhood_board = request.id_neighborhood_board, 
                    id_common_area = request.id_common_area,
                    date_exception = request.date_exception
                };

                var phoneNumbers = await _dbConnection.QueryAsync<string>(sqlSelectPhones, parametersPhones);

                // Consultar el nombre del área común
                var sqlSelectCommonArea = @"select name 
                                    from common_area 
                                    where id_common_area = @id_common_area";
                var commonAreaName = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                    sqlSelectCommonArea,
                    new { id_common_area = request.id_common_area });

                if (string.IsNullOrEmpty(commonAreaName))
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "El área común no fue encontrada."
                    };
                }

                // Actualizar las reservas
                var sqlUpdateReservations = @"update reservation 
                                       set enabled = false 
                                       where id_neighborhood_board_common_area = @id_neighborhood_board
                                       and id_common_area = @id_common_area
                                       and date_reservation = @date_exception";
                var rowsUpdated = await _dbConnection.ExecuteAsync(sqlUpdateReservations, parametersPhones);

                // Enviar mensajes a los usuarios
                foreach (var phoneNumber in phoneNumbers)
                {
                  
                    using (var httpClient = new HttpClient())
                    {
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                        var postData = new
                        {
                            number = phoneNumber,
                            message = $"Su reserva para el día {request.date_exception:yyyy-MM-dd} en el área común {commonAreaName} ha sido anulada. Si desea consultar al respecto, por favor contacte con su junta de vecinos."
                        };

                        var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                        var response = await httpClient.PostAsync(url, jsonContent);

                        if (!response.IsSuccessStatusCode)
                        {
                            throw new Exception($"Usuario actualizado pero error al enviar mensaje a {phone}: {response.ReasonPhrase}");
                        }
                    }
                }

                return new responseGenericAdm
                {
                    status = true,
                    message = "Operación completada exitosamente: Fecha de excepción agregada, reservas actualizadas y mensajes enviados."
                };
            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"Ocurrió un error: {ex.Message}"
                };
            }
        }

        // Método auxiliar para enviar mensajes
        private void SendMessage(string phoneNumber, string message)
        {
            // Lógica para enviar el mensaje (puedes usar Twilio, algún servicio de SMS o una API específica)
            Console.WriteLine($"Enviando mensaje a {phoneNumber}: {message}");
        }


        public async Task<List<string>> getDaysException(int id_neighborhood_board, int id_common_area)
        {
            try
            {
                var sql = @"select to_char(date_exception, 'YYYY-MM-DD') 
                            from exception_of_days
                            where id_neighborhood_board = @id_neighborhood_board
                            and id_common_area = @id_common_area
                            order by date_exception desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, id_common_area = id_common_area };

                var response = (await _dbConnection.QueryAsync<string>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)
            {
                return new List<string> { };
            }
        }

        public async Task<responseGenericAdm> updateCommonArea(updateCommenArea request)
        {
            try
            {
                var sql = @"update common_area
                            set name = @name, addres = @addres, start_time = @start_time, end_hours = @end_hours
                            where id_neighborhood_board = @id_neighborhood_board and id_common_area = @id_common_area"
                ;

                var parameters = new { name = request.name, addres = request.addres, start_time = TimeSpan.Parse(request.start_time), end_hours = TimeSpan.Parse(request.end_hours), id_neighborhood_board = request.id_neighborhood_board, id_common_area = request.id_common_area };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);
                if (rowsAffected > 0)
                {
                    var sqlHour = @"update maximum_hours_common_area
                            set number_hours = @number_hours
                            where id_neighborhood_board = @id_neighborhood_board and id_common_area = @id_common_area";

                    var parametersHour = new { number_hours = request.number_hours, id_neighborhood_board = request.id_neighborhood_board, id_common_area = request.id_common_area };

                    var rowsAffectedHour = await _dbConnection.ExecuteAsync(sqlHour, parametersHour);

                    if (rowsAffectedHour > 0)
                    {
                        return new responseGenericAdm
                        {
                            status = true,
                            message = "Area común actualizado"
                        };
                    }
                    else
                    {
                        return new responseGenericAdm
                        {
                            status = false,
                            message = "Area común no actualizado correctamente"
                        };
                    }
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "Area común no actualizado"
                    };
                }
            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        public async Task<List<emergencyAdm>> getEmergency(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select e.id_emergency, e.rut, e.address, e.latitude, e.longitude, 
                            e.date_emergency, c.category 
                            from emergency e, emergency_category c
                            where e.id_neighborhood_board_category = c.id_neighborhood_board
                            and e.id_category = c.id_category 
                            and e.id_neighborhood_board_category = @id_neighborhood_board";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };
                var emergyList = (await _dbConnection.QueryAsync<emergencyAdm>(sql, parameters)).ToList();

                foreach (var emergency in emergyList)
                {
                    emergency.url = $"https://www.google.com/maps/search/?api=1&query={emergency.latitude},{emergency.longitude}";
                }

                return emergyList;


            }
            catch (Exception ex)
            {
                return new List<emergencyAdm> { };
            }
        }

        public async Task<List<emergencyCategory>> getCategories(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select id_category, category
                            from emergency_category
                            where id_neighborhood_board = @id_neighborhood_board";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };
                var categoryList = (await _dbConnection.QueryAsync<emergencyCategory>(sql, parameters)).ToList();

                return categoryList;

            }
            catch (Exception ex)
            {
                return new List<emergencyCategory> { };
            }
        }

        public async Task<responseGenericAdm> createCategory(emergencyCategoryCreate request)
        {
            try
            {
                var sql = @"insert into emergency_category (id_neighborhood_board, category)
                            values (@id_neighborhood_board, @category)";

                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    category = request.category
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Categoria ingresado correctamente"
                    };
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "Categoria no ingresado"
                    };
                }
            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        public async Task<responseGenericAdm> updateCategory(emergencyCategoryUpdate request)
        {
            try
            {
                var sql = @"update emergency_category 
                            set category = @category
                            where id_neighborhood_board = @id_neighborhood_board 
                            and id_category = @id_category";

                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    category = request.category,
                    id_category = request.id_category
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Categoria actualizado correctamente"
                    };
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "Categoria no actualizado"
                    };
                }
            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        public async Task<List<reportsPendding>> getReportsPending(int id_neighborhood_board)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("API_BASE_URL");
                var sql = @"select id_report, rut, title, description, image_path, to_char(date_report, 'YYYY-MM-DD HH24:MM:SS') as date_report
                            from report
                            where id_neighborhood_board = @id_neighborhood_board
                            and id_status = 1
                            order by date_report desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var reportsList = (await _dbConnection.QueryAsync<reportsPendding>(sql, parameters)).ToList();

                foreach (var report in reportsList)
                {
                    if (report.image_path != null || report.image_path != "")
                    {
                        report.image_path = url + report.image_path;
                    }
                }

                return reportsList;

            }
            catch (Exception ex)
            {

                return new List<reportsPendding> { };
            }
        }

        public async Task<responseGenericAdm> updateReport(reportUpdate request)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("URL_WHATSAPP");
                var username = Environment.GetEnvironmentVariable("BASIC_AUTH_USERNAME");
                var password = Environment.GetEnvironmentVariable("BASIC_AUTH_PASSWORD");
                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
                var message = "";
                var phone = "";

                var sql = @"update report 
                            set id_status = @id_status, date_approved = @date_approved
                            where id_neighborhood_board = @id_neighborhood_board
                            and id_report = @id_report";

                var parameters = new { id_status = request.id_status, id_neighborhood_board = request.id_neighborhood_board, id_report = request.id_report, date_approved = DateTime.Now };

                var result = await _dbConnection.ExecuteAsync(sql, parameters);

                if (result > 0)
                {

                    var sqlPhone = @"select cellphone from users where rut = @rut";
                    var parametersPhone = new { rut = request.rut };

                    phone = await _dbConnection.QueryFirstAsync<string>(sqlPhone, parametersPhone);

                    var sqlCorreo = @"select name, email from neighborhood_board where id_neighborhood_board = @id_neighborhood_board ";
                    var parametersCorreo = new { id_neighborhood_board = request.id_neighborhood_board };

                    var info = await _dbConnection.QueryFirstOrDefaultAsync<infoJunta>(sqlCorreo, parametersCorreo);

                    if (request.id_status == 2)
                    {
                        await updateReports(request.id_neighborhood_board);
                        message = $"Su reporte {request.title} ingresado en la aplicación Barrio Activo para la junta de vecinos '{info.name}' ha sido aprobado";
                    }
                    else if (request.id_status == 3)
                    {
                        message = $"Su reporte {request.title} ingresado en la aplicación Barrio Activo para la junta de vecinos '{info.name}' ha sido rechazado. Cualquier duda contactarse con el administrador {info.email}";
                    }




                    using (var httpClient = new HttpClient())
                    {
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                        var postData = new
                        {
                            number = phone,
                            message = message
                        };

                        var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                        var response = await httpClient.PostAsync(url, jsonContent);

                        if (!response.IsSuccessStatusCode)
                        {
                            throw new Exception($"Usuario actualizado pero error al enviar mensaje a {phone}: {response.ReasonPhrase}");
                        }
                    }

                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Reporte actualizado correctamente"
                    };
                }

                return new responseGenericAdm
                {
                    status = false,
                    message = "Reportr no actualizado"
                };

            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        public async Task<List<reportsHistory>> getReportsHistory(int id_neighborhood_board)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("API_BASE_URL");
                var sql = @"select r.id_report, r.rut, r.title, r.description, r.image_path, to_char(r.date_report, 'YYYY-MM-DD HH24:MM:SS') as date_report, s.status
                            from report r, status s
                            where r.id_status = s.id_status
                            and r.id_neighborhood_board = id_neighborhood_board
                            and r.id_status != 1  
                            order by date_report desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var reportsList = (await _dbConnection.QueryAsync<reportsHistory>(sql, parameters)).ToList();

                foreach (var report in reportsList)
                {
                    if (report.image_path != null || report.image_path != "")
                    {
                        report.image_path = url + report.image_path;
                    }
                }

                return reportsList;

            }
            catch (Exception ex)
            {

                return new List<reportsHistory> { };
            }
        }

        public async Task<List<bankAccountAdm>> getBankAccount(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select * from bank_account
                            where id_neighborhood_board = @id_neighborhood_board";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var response = (await _dbConnection.QueryAsync<bankAccountAdm>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)
            {
                return new List<bankAccountAdm> { };
            }
        }


        public async Task<responseGenericAdm> addBankAccount(bankAccountAdd request)
        {
            try
            {
                var sql = @"insert into bank_account (id_neighborhood_board, bank, account_number, rut, email, name) 
                            values (@id_neighborhood_board, @bank, @account_number, @rut, @email, @name) ";

                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    bank = request.bank,
                    account_number = request.account_number,
                    rut = request.rut,
                    email = request.email,
                    name = request.name
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Cuenta bancaria ingresado correctamente"
                    };
                }
                else
                {
                    return new responseGenericAdm
                    {
                        status = false,
                        message = "Cuenta bancaria no ingresado"
                    };
                }


            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        public async Task<List<certicatePending>> getCertificatePending(int id_neighborhood_board)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("API_BASE_URL");
                var sql = @"select c.id_certificate, c.rut, c.evidence_image_path, to_char(c.request_day, 'YYYY-MM-DD') as request_day, 
                            c.evidence_pay_path, c.cellphone, u.first_name || ' ' || u.first_surname as name, c.addres
                            from certificate c, users u 
                            where c.rut = u.rut
                            and id_neighborhood_board = @id_neighborhood_board
                            and id_status = 1
                            and id_type_user = 3
                            order by request_day desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var listReport = (await _dbConnection.QueryAsync<certicatePending>(sql, parameters)).ToList();

                foreach (var report in listReport)
                {
                    if (report.evidence_pay_path != "" || report.evidence_pay_path != null)
                    {
                        report.evidence_pay_path = url + report.evidence_pay_path;
                    }
                    if (report.evidence_image_path != "" || report.evidence_image_path != null)
                    {
                        report.evidence_image_path = url + report.evidence_image_path;
                    }
                }

                return listReport;

            }
            catch (Exception ex)
            {
                return new List<certicatePending> { };
            }
        }


        public async Task<List<certicateHistory>> getCertificateHistory(int id_neighborhood_board)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("API_BASE_URL");
                var sql = @"select c.id_certificate, c.rut, c.evidence_image_path, to_char(c.request_day, 'YYYY-MM-DD') as request_day, c.evidence_pay_path, c.cellphone, s.status,  to_char(c.approved_date, 'YYYY-MM-DD') as approved_date, c.approved_by, c.pdf_path
                            from certificate c, status s
                            where c.id_status = s.id_status 
                            and c.id_neighborhood_board = @id_neighborhood_board
                            and c.id_status != 1
                            order by c.request_day desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var listReport = (await _dbConnection.QueryAsync<certicateHistory>(sql, parameters)).ToList();

                foreach (var report in listReport)
                {
                    if (report.evidence_pay_path != "" & report.evidence_pay_path != null)
                    {
                        report.evidence_pay_path = url + report.evidence_pay_path;
                    }
                    if (report.evidence_image_path != "" & report.evidence_image_path != null)
                    {
                        report.evidence_image_path = url + report.evidence_image_path;
                    }
                    if (report.approved_date == null && report.approved_by == null)
                    {
                        report.approved_date = "";
                        report.approved_by = "";
                    }
                    if (report.pdf_path != "" & report.pdf_path != null)
                    {
                        report.pdf_path = url + report.pdf_path;
                    }
                    else
                    {
                        report.pdf_path = "";
                    }
                }

                return listReport;

            }
            catch (Exception ex)
            {
                return new List<certicateHistory> { };
            }
        }


        public async Task<responseGenericAdm> updateCertificate(updateCerticate request)
        {
            try
            {
                var urlBase = Environment.GetEnvironmentVariable("API_BASE_URL");
                var url = Environment.GetEnvironmentVariable("URL_WHATSAPP");
                var username = Environment.GetEnvironmentVariable("BASIC_AUTH_USERNAME");
                var password = Environment.GetEnvironmentVariable("BASIC_AUTH_PASSWORD");
                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
                var urlCertificado = "";
                var message = "";

                var sql = @"update certificate
                            set id_status = @id_status, approved_date = @approved_date, approved_by = @approved_by
                            where id_neighborhood_board = @id_neighborhood_board
                            and id_certificate = @id_certificate
                            and rut = @rut";

                var parameters = new
                {
                    id_status = request.id_status,
                    approved_date = DateTime.Now,
                    approved_by = request.approved_by,
                    id_neighborhood_board = request.id_neighborhood_board,
                    id_certificate = request.id_certificate,
                    rut = request.rut
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    var sqlInfo = @"select n.rut, n.name, n.email, n.url_signature, c.commune, r.region
                                    from neighborhood_board n, commune c, region r
                                    where n.id_commune = c.id_commune
                                    and n.id_region = r.id_region ";

                    var parametersInfo = new { id_neighborhood_board = request.id_neighborhood_board };

                    var info = await _dbConnection.QueryFirstOrDefaultAsync<infoJuntaCertificate>(sqlInfo, parametersInfo);

                    var urlSignature = urlBase + info.url_signature;


                    if (request.id_status == 2)
                    {
                        var htmlContent = $@"
<!DOCTYPE html>
<html lang=""es"">
<head>
    <meta charset=""UTF-8"">
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
    <title>Certificado de Residencia</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            line-height: 1.5;
        }}
        .header, .footer, .title {{
            text-align: center;
            margin-bottom: 20px;
        }}
        .content {{
            max-width: 600px;
            margin: auto;
        }}
        .signature {{
            margin-top: 40px;
            text-align: center;
        }}
        .signature img {{
            height: 100px; 
            width: auto;
        }}
    </style>
</head>
<body>
    <div class=""content"">
        <div class=""header"">
            <h1>JUNTA DE VECINOS '{info.name}'</h1>
            <p>Comuna de {info.commune}, Región {info.region}</p>
            <p>RUT: {info.rut}</p>
            <p>N°: {request.id_certificate}</p>
        </div>

        
        <h3 class=""title"">CERTIFICA</h3>
        
        <p>Que, {request.name}, Cédula Nacional de Identidad N° {request.rut}, registra su domicilio particular en {request.addres}, comuna de {info.commune}, región {info.region}, ubicado en el territorio donde esta Junta de Vecinos desarrolla sus funciones.</p>

        <div class=""signature"">
            <img src={urlSignature} alt=""Firma del presidente"">
            <p>TIMBRE</p>
        </div>

        <div class=""footer"">
            <p>El documento, firmado el {DateTime.Now.ToString("dd/MM/yyyy")}, podrá ser utilizado para los fines que se estimen convenientes durante un plazo de 30 días.</p>
        </div>
    </div>
</body>
</html>
";


                        var pdfBytes = _pdfGeneratorService.GeneratePdfFromHtml(htmlContent);

                        var fileName = Guid.NewGuid().ToString() + ".pdf";
                        //var filePath = Path.Combine("C:\\Capstone", fileName);
                        var filePath = Path.Combine("/certificate/pdf", fileName);
                        var filePathSave = Path.Combine("wwwroot/certificate/pdf", fileName);
                        urlCertificado = filePath;

                        var sqlCertificate = @"update certificate set pdf_path = @pdf_path 
                                               where id_neighborhood_board = @id_neighborhood_board and id_certificate = @id_certificate and rut = @rut";

                        var parametersCertificate = new
                        {
                            id_neighborhood_board = request.id_neighborhood_board,
                            id_certificate = request.id_certificate,
                            rut = request.rut,
                            pdf_path = urlCertificado
                        };

                        var executeSQL = await _dbConnection.ExecuteAsync(sqlCertificate, parametersCertificate);

                        // Guardar el PDF en la ruta especificada
                        await File.WriteAllBytesAsync(filePathSave, pdfBytes);

                        message = $"La solicitud de certificado desde la aplicación Barrio Activo para la junta de vecinos '{info.name}' fue aprobado.";




                    }
                    else if (request.id_status == 3)
                    {
                        message = @$"La solicitud de certificado desde la aplicación Barrio Activo para la junta de vecinos '{info.name}' fue rechazado.
Si tiene alguna duda se puede contactar con el administrador {info.email}";
                    }

                    using (var httpClient = new HttpClient())
                    {
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
                        if (request.id_status == 2)
                        {
                            var postData = new
                            {
                                number = request.cellphone,
                                message = message,
                                //urlMedia = "https://capstone-api-core.aniuskaojeda.dev/certificate/pay/certificate_prueba.pdf"
                                urlMedia = urlBase + urlCertificado
                            };

                            var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                            var response = await httpClient.PostAsync(url, jsonContent);

                            if (!response.IsSuccessStatusCode)
                            {
                                throw new Exception($"Usuario actualizado pero error al enviar mensaje a {request.cellphone}: {response.ReasonPhrase}");
                            }
                        }
                        else
                        {
                            var postData = new
                            {
                                number = request.cellphone,
                                message = message
                            };

                            var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                            var response = await httpClient.PostAsync(url, jsonContent);

                            if (!response.IsSuccessStatusCode)
                            {
                                throw new Exception($"Usuario actualizado pero error al enviar mensaje a {request.cellphone}: {response.ReasonPhrase}");
                            }
                        }

                    }

                    return new responseGenericAdm
                    {
                        status = true,
                        message = "Certificado actualizado correctamente"
                    };

                }

                return new responseGenericAdm
                {
                    status = false,
                    message = "Certificado no actualizado"
                };

            }
            catch (Exception ex)
            {
                return new responseGenericAdm
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

    }
}
