﻿namespace api_core.Models
{
    public class dashboardModel
    {

        public class DashboardData
        {
            public IEnumerable<EmergencyData> Emergencies { get; set; }
            public IEnumerable<ReportData> Reports { get; set; }
            public IEnumerable<UserStatusData> Users { get; set; }
        }

        public class EmergencyData
        {
            public int Year { get; set; }
            public int Month { get; set; }
            public string Category { get; set; }
            public int Count { get; set; }
        }

        public class ReportData
        {
            public int Year { get; set; }
            public int Month { get; set; }
            public string Status { get; set; }
            public int Count { get; set; }
        }

        public class UserStatusData
        {
            public string Status { get; set; }
            public int Count { get; set; }
        }

    }
}
