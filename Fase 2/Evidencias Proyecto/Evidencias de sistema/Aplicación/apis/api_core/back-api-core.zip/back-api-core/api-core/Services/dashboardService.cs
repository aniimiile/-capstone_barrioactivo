﻿using Dapper;
using System.Data;
using static api_core.Models.dashboardModel;
namespace api_core.Services
{
    public class dashboardService
    {
        private readonly IDbConnection _dbConnection;
        private readonly ILogger<dashboardService> _logger;

        public dashboardService(ILogger<dashboardService> logger, IDbConnection dbConnection)
        {
            _logger = logger;
            _dbConnection = dbConnection;
        }

        public async Task<IEnumerable<EmergencyData>> GetEmergencyData(int neighborhoodId)
        {
            var query = @"
            SELECT DATE_PART('year', e.date_emergency) AS year,
                   DATE_PART('month', e.date_emergency) AS month,
                   c.category AS Category, 
                   COUNT(e.id_category) AS Count
            FROM emergency e, emergency_category c
            WHERE e.id_neighborhood_board_user = c.id_neighborhood_board
              AND c.id_category = e.id_category
              AND e.id_neighborhood_board_user = @neighborhoodId
            GROUP BY c.category, year, month
            ORDER BY year, month, category";
            return await _dbConnection.QueryAsync<EmergencyData>(query, new { neighborhoodId });
        }

        public async Task<IEnumerable<ReportData>> GetReportData(int neighborhoodId)
        {
            var query = @"
            SELECT DATE_PART('year', r.date_report) AS year,
                   DATE_PART('month', r.date_report) AS month,
                   s.status AS Status, COUNT(r.id_status)  AS Count
            FROM report r, status s
            WHERE r.id_status = s.id_status
              AND r.id_neighborhood_board = @neighborhoodId
            GROUP BY s.status, year, month";
            return await _dbConnection.QueryAsync<ReportData>(query, new { neighborhoodId });
        }

        public async Task<IEnumerable<UserStatusData>> GetUserStatusData(int neighborhoodId)
        {
            var query = @"
            SELECT s.status AS Status, COUNT(u.rut) AS Count
            FROM user_neighborhood_board u, status s
            WHERE u.id_status = s.id_status 
              AND u.id_neighborhood_board = @neighborhoodId
            GROUP BY s.status";
            return await _dbConnection.QueryAsync<UserStatusData>(query, new { neighborhoodId });
        }

        public async Task<DashboardData> GetDashboardData(int neighborhoodId)
        {
            var emergencyData = await GetEmergencyData(neighborhoodId);
            var reportData = await GetReportData(neighborhoodId);
            var userStatusData = await GetUserStatusData(neighborhoodId);

            return new DashboardData
            {
                Emergencies  = (IEnumerable<EmergencyData>)emergencyData,
                Reports = (IEnumerable<ReportData>)reportData,
                Users = (IEnumerable<UserStatusData>)userStatusData
            };
        }

    }
}
