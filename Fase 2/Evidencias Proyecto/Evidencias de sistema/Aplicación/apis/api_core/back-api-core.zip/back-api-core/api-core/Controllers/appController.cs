﻿using Microsoft.AspNetCore.Mvc;
using api_core.Security;
using static api_core.Models.appModel;
using System;
using System.IO;
using System.Threading.Tasks;
using api_core.Services;
using System.Net.NetworkInformation;
using static api_core.Models.appModel;
using static System.Net.Mime.MediaTypeNames;
using static api_core.Models.faceValidationModel;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using Sprache;
namespace api_core.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class appController : ControllerBase
    {
        private readonly ILogger<appController> _logger;
        private readonly appService _appService;

        public appController(ILogger<appController> logger, appService appService)
        {
            _logger = logger;
            _appService = appService;
        }

        [HttpPost("login")]
        [ApiKeyAuth]
        public async Task<responseGeneric> login(requestLogin request)
        {
            _logger.LogInformation($"Q: Login: {request.email}");
            try
            {
                var response = await _appService.login(request);

                return new responseGeneric
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        [HttpPost("report")]
        [ApiKeyAuth]
        public async Task<responseGeneric> report([FromForm] requestReportFront request)
        {
            _logger.LogInformation($"Q: Info: {request}");
            try
            {
                // Obtener la ruta desde el archivo .env
                var uploadPath = Environment.GetEnvironmentVariable("PHOTO_REPORT_PATH");
                string imagePath = "";
                string imageFileName = "";

                if (!string.IsNullOrEmpty(uploadPath) && request.image != null)
                {
                    // Generar un nombre único para la imagen
                    imageFileName = Guid.NewGuid().ToString() + Path.GetExtension(request.image.FileName);

                    // Crear la ruta completa para guardar la imagen
                    imagePath = Path.Combine(uploadPath, imageFileName);

                    _logger.LogInformation($"Q: imagePath: {imagePath}");

                    // Guardar la imagen en la ruta especificada
                    using (var stream = new FileStream(imagePath, FileMode.Create))
                    {
                        await request.image.CopyToAsync(stream);
                    }
                }
                else if (request.image == null)
                {
                    _logger.LogInformation("No image provided in the request.");
                }

                // Crear el objeto requestDB para enviar a la capa de servicio
                var requestDB = new requestReport
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    rut = request.rut,
                    title = request.title,
                    description = request.description,
                    image_path = string.IsNullOrEmpty(imageFileName) ? null : Path.Combine("/img/", imageFileName)
                };

                // Llamar al servicio con los datos preparados
                var result = await _appService.report(requestDB);

                return new responseGeneric
                {
                    status = result.status,
                    message = result.message
                };
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        [HttpGet("neighborhoodBoard")]
        [ApiKeyAuth]

        public async Task<List<neighborhoodBoard>> listNeighborhoodBoard()
        {
            _logger.LogInformation($"Q: listNeighborhoodBoard ");
            try
            {


                var result = await _appService.listNeighborhoodBoard();

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<neighborhoodBoard>();

            }

        }


        [HttpPost("user")]
        [ApiKeyAuth]
        public async Task<responseGeneric> createUser([FromForm] requestCreateUser request)
        {
            _logger.LogInformation($"Q: Info: {request}");
            try
            {
                // Obtener la ruta desde el archivo .env
                var uploadPath = Environment.GetEnvironmentVariable("ADRESS_VERIFICATION_PATH");
                var documentFileName = ""; 
                string documentPath = "";
                if (string.IsNullOrEmpty(uploadPath))
                {
                    _logger.LogInformation($"R: The addres verification upload path is not configured.");
                    return new responseGeneric
                    {
                        status = false,
                        message = "The addres verification upload path is not configured."
                    };
                }

                if (request.document_verification != null)
                {
                    documentFileName = Guid.NewGuid().ToString() + Path.GetExtension(request.document_verification.FileName);

                    // Crear las rutas completas para guardar los documentos 
                    documentPath = Path.Combine(uploadPath, documentFileName);

                    _logger.LogInformation($"Q: documentPath: {documentPath}");

                    using (var stream = new FileStream(documentPath, FileMode.Create))
                    {
                        await request.document_verification.CopyToAsync(stream);
                    }
                }

                var requestDB = new Users
                {
                    Rut = request.Rut,
                    First_Name = request.First_Name,
                    Second_Name = request.Second_Name,
                    First_Surname = request.First_Surname,
                    Second_Surname = request.Second_Surname,
                    Birthdate = request.Birthdate,
                    Email = request.Email,
                    Password = request.Password,
                    Address = request.Address,
                    Address_Verification_Url = $"/address_documents/{documentFileName}",
                    Cellphone = request.Cellphone,
                    Id_Type_User = 3,
                    Id_Status = 1,
                    Id_Neighborhood_Board = request.Id_Neighborhood_Board,
                    Emergency_enabled = false,
                    Creation_Date = DateTime.Now,
                    Enabled = false
                };

                var result = await _appService.createUser(requestDB);

                return new responseGeneric
                {
                    status = result.status,
                    message = result.message
                };
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }

        }


        [HttpGet("emergency/category")]
        [ApiKeyAuth]

        public async Task<List<emergencyCategoryList>> listEmergencyCategory(int id_neighborhood_board)
        {
            _logger.LogInformation($"Q: id_neighborhood_board ");
            try
            {


                var result = await _appService.listEmergencyCategory(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<emergencyCategoryList>();

            }

        }

        [HttpGet("reports")]
        [ApiKeyAuth]
        public async Task<List<reports>> listReports(int id_neighborhood_board)
        {
            _logger.LogInformation($"Q: id_neighborhood_board ");
            try
            {


                var result = await _appService.getReports(id_neighborhood_board);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<reports>();

            }

        }



        [HttpPost("emergency")]
        [ApiKeyAuth]
        public async Task<responseGeneric> emergency(emergencyRequest emergency)
        {
            _logger.LogInformation($"Q: Emergency: id_neighborhood: {emergency.id_neighborhood}, rut {emergency.rut}");
            try
            {
                var response = await _appService.emergency(emergency);

                var sendRmergency = _appService.sendEmergency(emergency.id_neighborhood, emergency.id_category, emergency.address, emergency.description, emergency.latitude, emergency.longitude);

                return new responseGeneric
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };




            }
        }


        [HttpGet("user")]
        [ApiKeyAuth]

        public async Task<User> getUserInfo(string email)
        {
            _logger.LogInformation($"Q: user: {email} ");
            try
            {


                var result = await _appService.getUserInfo(email);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new User { };

            }

        }

        [HttpGet("commonArea")]
        [ApiKeyAuth]
        public async Task<List<commonArea>> getCommonArea(int id_neighborhood_board)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {


                var result = await _appService.listCommonArea(id_neighborhood_board);

                _logger.LogInformation($"R: commonArea: {result} ");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<commonArea> { };

            }

        }


        [HttpGet("reservationsCommonAreaDates")]
        [ApiKeyAuth]
        public async Task<List<commonAreaDate>> reservationsCommonAreaDates(int id_neighborhood_board, int id_common_area)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {


                var result = await _appService.getCommonAreaDates(id_neighborhood_board, id_common_area);

                _logger.LogInformation($"R: reservations: {result} ");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<commonAreaDate> { };

            }

        }

        [HttpGet("reservationsCommonAreaHours")]
        [ApiKeyAuth]
        public async Task<List<commonAreaHours>> reservationsCommonAreaHours(int id_neighborhood_board, int id_common_area, string date)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {


                var result = await _appService.getCommonAreaHours(id_neighborhood_board, id_common_area, date);

                _logger.LogInformation($"R: reservations: {result} ");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<commonAreaHours> { };

            }

        }

        [HttpPost("reservation")]
        [ApiKeyAuth]
        public async Task<responseGeneric> reservation(requestReservation request)
        {
            _logger.LogInformation($"Q: reservation");
            try
            {
                var response = await _appService.reservation(request);

                return new responseGeneric
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };




            }
        }

        [HttpGet("reservations")]
        [ApiKeyAuth]
        public async Task<List<reservation>> reservations(int id_neighborhood_board, string rut)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {

                var result = await _appService.getReservations(id_neighborhood_board, rut);

                _logger.LogInformation($"R: reservation: {result} ");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<reservation> { };

            }

        }


        [HttpPost("reservation/disable")]
        [ApiKeyAuth]
        public async Task<responseGeneric> reservationUpdate(requestUpdateReservation request)
        {
            _logger.LogInformation($"Q: reservation");
            try
            {
                var response = await _appService.updateReservation(request);

                return new responseGeneric
                {
                    status = response.status,
                    message = response.message
                };

            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };




            }
        }

        [HttpGet("bankAccount")]
        [ApiKeyAuth]
        public async Task<List<bankAccount>> bankAccount(int id_neighborhood_board)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {

                var result = await _appService.getBankAccount(id_neighborhood_board);

                _logger.LogInformation($"R: bankAccount: {result} ");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<bankAccount> { };

            }

        }

        [HttpPost("certificate")]
        [ApiKeyAuth]
        public async Task<responseGeneric> certificate([FromForm] requestCertificateFront request)
        {
            _logger.LogInformation($"Q: Info: {request}");
            try
            {
                // Obtener la ruta desde el archivo .env
                var uploadPathAddres = Environment.GetEnvironmentVariable("PHOTO_CERTIFICATE_ADDRESS");
                var uploadPathPay = Environment.GetEnvironmentVariable("PHOTO_CERTIFICATE_PAY");
                string imagePathAddress = "";
                string imagePathPay = "";
                if (string.IsNullOrEmpty(uploadPathAddres) || string.IsNullOrEmpty(uploadPathPay))
                {
                    _logger.LogInformation($"R: The image upload path is not configured.");
                    return new responseGeneric
                    {
                        status = false,
                        message = "The image upload path is not configured."
                    };
                }

                var imageFileNameAdress  = Guid.NewGuid().ToString() + Path.GetExtension(request.evidence_addres.FileName);
                var imageFileNamePay = Guid.NewGuid().ToString() + Path.GetExtension(request.evidence_pay.FileName);

                if (request.evidence_addres != null)
                {

                    // Crear las rutas completas para guardar las imágenes
                    imagePathAddress = Path.Combine(uploadPathAddres, imageFileNameAdress);

                    _logger.LogInformation($"Q: imagePathAddress: {imagePathAddress}");

                    using (var stream = new FileStream(imagePathAddress, FileMode.Create))
                    {
                        await request.evidence_addres.CopyToAsync(stream);
                    }
                }


                if (request.evidence_pay != null)
                {

                    // Crear las rutas completas para guardar las imágenes
                    imagePathPay = Path.Combine(uploadPathPay, imageFileNamePay);

                    _logger.LogInformation($"Q: imagePathAdress: {imagePathPay}");

                    using (var stream = new FileStream(imagePathPay, FileMode.Create))
                    {
                        await request.evidence_pay.CopyToAsync(stream);
                    }
                }

                var requestDB = new requestCertificate
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    rut = request.rut,
                    evidence_addres_path = $"/certificate/address/{imageFileNameAdress}", 
                    evidence_pay_path = $"/certificate/pay/{imageFileNamePay}", 
                    cellphone = request.cellphone
                };

                var result = await _appService.certificate(requestDB);

                return new responseGeneric
                {
                    status = result.status,
                    message = result.message
                };
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }

        }


        [HttpGet("emergency/history")]
        [ApiKeyAuth]
        public async Task<List<emergencyUserResponse>> emergencyHistorys(int id_neighborhood_board, string rut)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {

                var result = await _appService.getEmergencyUser(id_neighborhood_board, rut);

              
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<emergencyUserResponse> { };

            }

        }


        [HttpGet("report/history")]
        [ApiKeyAuth]
        public async Task<List<reportUserResponse>> reportHistorys(int id_neighborhood_board, string rut)
        {
            _logger.LogInformation($"Q: id_neighborhood_board: {id_neighborhood_board} ");
            try
            {

                var result = await _appService.getReportsUser(id_neighborhood_board, rut);


                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"E: {ex.Message}");

                return new List<reportUserResponse> { };

            }

        }
    }
}
