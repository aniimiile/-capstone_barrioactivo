﻿using StackExchange.Redis;
using System.Runtime.CompilerServices;

namespace api_core.Models
{
    public class admModel
    {
        public class responseGenericAdm
        {
            public bool status { get; set; }
            public string message { get; set; }
        }

        public class reportsAdm
        {
            public int id_neighborhood_board { get; set; }
            public int id_report { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public string image_path { get; set; }
            public string date_report { get; set; }
            public string first_name { get; set; }
            public string first_surname { get; set; }
        }

        public class requestLoginAdm
        {
            public string email { get; set; }
            public string password { get; set; }
        }

        public class UserAdm
        {
            public string Rut { get; set; }

            public string First_Name { get; set; }
            public string? Second_Name { get; set; }
            public string First_Surname { get; set; }
            public string? Second_Surname { get; set; }
            public DateTime? Birthdate { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
            public string? Address { get; set; }
            public string Cellphone { get; set; }
            public int Id_Neighborhood_Board { get; set; }
            public bool? Emergency_enabled { get; set; }
            public int id_Type_User { get; set; }

        }

        public class Neighborhood
        {
            public string rut { get; set; }
            public string first_name { get; set; }
            public string second_name { get; set; }
            public string first_surname { get; set; }
            public string second_surname { get; set; }
            public string birthdate { get; set; }
            public string email { get; set; }
            public string address { get; set; }
            public string cellphone { get; set; }
            public bool emergency_enabled { get; set; }
            public string creation_date { get; set; }
            public bool enabled { get; set; }
            public int id_status { get; set; }
            public string address_verification_url { get; set; }
        }

        public class UpdateUser
        {
            public int id_status { get; set; }
            public string rut { get; set; }
            public int id_neighborhood_board { get; set; }

        }

        public class infoJunta
        {
            public string name { get; set; }
            public string email { get; set; }
        }

        public class infoJuntaCertificate : infoJunta
        {
            public string commune { get; set; }
            public string region { get; set; }
            public string url_signature { get; set; }
            public string rut { get; set; }
        }

        public class reservasList
        {
            public string rut { get; set; }
            public string name { get; set; }
            public string date_reservation { get; set; }
            public string start_hour { get; set; }
            public string end_hour { get; set; }
            public int number_hours { get; set; }
        }

        public class commonAreaAdm
        {
            public int id_common_area { get; set; }
            public string name { get; set; }
            public string addres { get; set; }
            public string start_time { get; set; }
            public string end_hours { get; set; }
            public int number_hours { get; set; }
        }

        public class addCommonArea
        {
            public string name { get; set; }
            public string addres { get; set; }
            public string start_time { get; set; }
            public string end_hours { get; set; }
            public int number_hours { get; set; }
            public int id_neighborhood_board { get; set; }

        }

        public class daysException
        {
            public int id_neighborhood_board { get; set; }
            public int id_common_area { get; set; }
            public DateTime date_exception { get; set; }
        }

        public class updateCommenArea
        {
            public string name { get; set; }
            public string addres { get; set; }
            public string start_time { get; set; }
            public string end_hours { get; set; }
            public int number_hours { get; set; }
            public int id_neighborhood_board { get; set; }

            public int id_common_area { get; set; }
        }

        public class emergencyAdm
        {
            public int id_emergency { get; set; }
            public string rut { get; set; }
            public string address { get; set; }
            public string latitude { get; set; }
            public string longitude { get; set; }
            public string url { get; set; }
            public string date_emergency { get; set; }
            public string category { get; set; }
        }

        public class emergencyCategory
        {
            public int id_category { get; set; }
            public string category { get; set; }
        }


        public class emergencyCategoryCreate
        {
            public int id_neighborhood_board { get; set; }
            public string category { get; set; }
        }

        public class emergencyCategoryUpdate
        {
            public int id_neighborhood_board { get; set; }
            public int id_category { get; set; }
            public string category { get; set; }
        }

        public class reportsPendding
        {
            public int id_report { get; set; }
            public string rut { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public string image_path { get; set; }

            public string date_report { get; set; }
        }

        public class reportUpdate
        {
            public int id_neighborhood_board { get; set; }
            public int id_report { get; set; }
            public int id_status { get; set; }
            public string rut { get; set; }
            public string title { get; set; }

        }

        public class reportsHistory
        {
            public int id_report { get; set; }
            public string rut { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public string image_path { get; set; }

            public string date_report { get; set; }
            public string status { get; set; }
        }

        public class bankAccountAdm
        {
            public int id_bank_account { get; set; }
            public string bank { get; set; }
            public string account_number { get; set; }
            public string rut { get; set; }
            public string email { get; set; }
        }


        public class bankAccountAdd
        {
            public int id_neighborhood_board { get; set; }
            public string bank { get; set; }
            public string account_number { get; set; }
            public string rut { get; set; }
            public string email { get; set; }
            public string name { get; set; }
        }

        public class certicatePending
        {
            public int id_certificate { get; set; }
            public string rut { get; set; }
            public string evidence_image_path { get; set; }
            public string request_day { get; set; }
            public string evidence_pay_path { get; set; }
            public string cellphone { get; set; }
            public string name { get; set; }
            public string addres { get; set; }
        }

        public class certicateHistory : certicatePending
        {
            public string status { get; set; }
            public string approved_date { get; set; }
            public string approved_by { get; set; }
            public string pdf_path { get; set; }
        }

        public class updateCerticate
        {
            public int id_neighborhood_board { get; set; }
            public int id_certificate { get; set; }
            public string rutPresident { get; set; }
            public string rut { get; set; }
            public int id_status { get; set; }

            public string approved_by { get; set; }
            public string cellphone { get; set; }
            public string name { get; set; }

            public string addres { get; set; }

        }
    }
}
