﻿using static api_core.Models.dashboardModel;
using Microsoft.AspNetCore.SignalR;
namespace api_core.Hubs
{
    public class dashboardHub : Hub
    {
        public async Task SendDashboardUpdate(DashboardData dashboardData)
        {
            // Enviar los datos del dashboard a todos los clientes conectados
            await Clients.All.SendAsync("ReceiveDashboardData", dashboardData);
        }
    }
}
