﻿using System.ComponentModel.DataAnnotations;

namespace api_core.Models
{
    public class appModel
    {
        public class requestLogin
        {
            public string email { get; set; }
            public string password { get; set; }
        }

        public class responseGeneric
        {
            public bool status { get; set; }
            public string message { get; set; }
        }

        public class Users
        {
            public string Rut { get; set; }

            public string First_Name { get; set; }
            public string? Second_Name { get; set; }
            public string First_Surname { get; set; }
            public string? Second_Surname { get; set; }
            public DateTime? Birthdate { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
            public string? Address { get; set; }
            public string? Address_Verification_Url { get; set; }
            public string Cellphone { get; set; }
            public int? Id_Type_User { get; set; }
            public int? Id_Status { get; set; }
            public int Id_Neighborhood_Board { get; set; }
            public bool? Emergency_enabled { get; set; }
            public DateTime? Creation_Date { get; set; }
            public bool? Enabled { get; set; }

        }


        public class requestReport
        {
            public int id_neighborhood_board { get; set; }
            public string rut { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public string image_path { get; set; }
        }

        public class requestReportFront
        {
            public int id_neighborhood_board { get; set; }
            public string rut { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public IFormFile? image { get; set; }


        }


        public class neighborhoodBoard
        {
            public int id_neighborhood_board { get; set; }
            public string name { get; set; }
            public string email { get; set; }
            public string cellphone { get; set; }
        }

        public class emergencyCategoryList
        {
            public int id_category { get; set; }
            public string category { get; set; }
        }

        public class requestCreateUser
        {
            public string Rut { get; set; }

            public string First_Name { get; set; }
            public string? Second_Name { get; set; }
            public string First_Surname { get; set; }
            public string? Second_Surname { get; set; }
            public DateTime? Birthdate { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
            public string? Address { get; set; }
            public string Cellphone { get; set; }
            public int Id_Neighborhood_Board { get; set; }
            public IFormFile document_verification { get; set; }
        }

        public class reports
        {
            public int id_neighborhood_board { get; set; }
            public int id_report { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public string image_path { get; set; }
            public string date_report { get; set; }
            public string first_name { get; set; }
            public string first_surname { get; set; }
        }

        public class emergency
        {
            public int id_neighborhood_board_user { get; set; }
            public int id_neighborhood_board_category { get; set; }
            public int? id_emergency { get; set; }
            public int id_category { get; set; }
            public string rut { get; set; }
            public string? address { get; set; }
            public string? description { get; set; }
            public string? latitude { get; set; }
            public string? longitude { get; set; }
        }

        public class emergencyRequest
        {
            public int id_neighborhood { get; set; }
            public int id_category { get; set; }
            public string rut { get; set; }
            public string address { get; set; }
            public string? description { get; set; }
            public string? latitude { get; set; }
            public string? longitude { get; set; }
        }


        public class User
        {
            public string Rut { get; set; }

            public string First_Name { get; set; }
            public string? Second_Name { get; set; }
            public string First_Surname { get; set; }
            public string? Second_Surname { get; set; }
            public DateTime? Birthdate { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
            public string? Address { get; set; }
            public string Cellphone { get; set; }
            public int Id_Neighborhood_Board { get; set; }
            public bool? Emergency_enabled { get; set; }

        }

        public class commonArea
        {
            public int id_common_area { get; set; }
            public string name { get; set; }
            public string addres { get; set; }
            public TimeSpan start_time { get; set; }
            public TimeSpan end_hours { get; set; }

            public int number_hours { get; set; }

        }

        public class reservations
        {
            public string available_day { get; set; }
            public string available_hour { get; set; }
        }

        public class requestReservation
        {
            public int id_neighborhood_board { get; set; }
            public int id_common_area { get; set; }
            public string rut { get; set; }
            public DateOnly date_reservation { get; set; }
            public TimeOnly start_hour { get; set; }
            public TimeOnly end_hour { get; set; }
            public int number_hours { get; set; }
        }

        public class reservation
        {
            public int id_reservation { get; set; }
            public int id_common_area { get; set; }
            public string date_reservation { get; set; }
            public TimeSpan start_hour { get; set; }
            public TimeSpan end_hour { get; set; }
            public int number_hours { get; set; }
            public bool enabled { get; set; }
        }

        public class requestUpdateReservation
        {
            public int id_neighborhood_board { get; set; }
            public int id_common_area { get; set; }
            public int id_reservation { get; set; }
            public string rut { get; set; }
        }

        public class bankAccount
        {
            public string bank { get; set; }
            public string rut { get; set; }
            public string account_number { get; set; }
            public string name { get; set; }
            public string email { get; set; }

        }

        public class commonAreaDate
        {
            public string available_day { get; set; }
        }

        public class commonAreaHours
        {
            public string StartHour { get; set; }
            public string EndHour { get; set; }
        }


        public class requestCertificateFront
        {
            public int id_neighborhood_board { get; set; }
            public string rut { get; set; }
            public IFormFile evidence_addres { get; set; }
            public IFormFile evidence_pay { get; set; }
            public string cellphone { get; set; }

            public string? addres { get; set; }


        }

        public class requestCertificate
        {
            public int id_neighborhood_board { get; set; }
            public string rut { get; set; }
            public string evidence_addres_path { get; set; }
            public string evidence_pay_path { get; set; }
            public string cellphone { get; set; }
            public string? addres { get; set; }


        }

        public class emergencyUserDB
        {

            public int? id_emergency { get; set; }
            public int id_category { get; set; }
            public string category { get; set; }
            public string? address { get; set; }
            public string? description { get; set; }
            public string? latitude { get; set; }
            public string? longitude { get; set; }
            public string date_emergency { get; set; }

        }

        public class emergencyUserResponse
        {


            public string category { get; set; }
            public string? address { get; set; }
            public string? description { get; set; }
            
            public string googleMaps { get; set; }

            public string date_emergency { get; set; }


        }

        public class reportUserDB
        {

            public string title { get; set; }
            public string? description { get; set; }
            public string? image_path { get; set; }
            public string? status { get; set; }

        }

        public class reportUserResponse
        {

            public int id_neighborhood_board { get; set; }
            public string title { get; set; }
            public string? description { get; set; }
            public string? url_image { get; set; }
            public string? status { get; set; }


        }
    }
}