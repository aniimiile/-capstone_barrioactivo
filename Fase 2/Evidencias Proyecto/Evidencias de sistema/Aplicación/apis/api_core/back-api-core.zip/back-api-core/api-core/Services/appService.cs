﻿using Dapper;
using Microsoft.AspNetCore.Identity.Data;
using StackExchange.Redis;
using System.Data;
using System.Data.Common;
using System.Diagnostics.Eventing.Reader;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Security.AccessControl;
using Newtonsoft.Json;
using System.Text.Json;
using static api_core.Models.appModel;
using Npgsql;
using System.Text;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.SignalR;
using api_core.Hubs;

namespace api_core.Services
{
    public class appService
    {
        private readonly ILogger<appService> _logger;
        private readonly IDbConnection _dbConnection;
        private readonly IConnectionMultiplexer _redis;
        private readonly IHubContext<dashboardHub> _hubContext;
        private readonly dashboardService _dashboardService;

        public appService(ILogger<appService> logger, IDbConnection dbConnection, IConnectionMultiplexer redis, IHubContext<dashboardHub> hubContext, dashboardService dashboardService)
        {
            _logger = logger;
            _dbConnection = dbConnection;
            _redis = redis;
            _hubContext = hubContext;
            _dashboardService = dashboardService;
        }

        //Hacer login 
        public async Task<responseGeneric> login(requestLogin request)
        {
            try
            {
                var sql = @"select u.email, u.password, n.id_status 
                              from users u, user_neighborhood_board n 
                             where u.rut = n.rut 
						       and n.id_type_user = 3
                               and u.email = @email
                               and u.password = @password";

                var parameters = new { email = request.email, password = request.password };

                var response = await _dbConnection.QueryFirstOrDefaultAsync<Users>(sql, parameters);

                if (response == null)
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "Creedenciales incorrectas"
                    };
                }

                if (response.Id_Status == 2)
                {
                    return new responseGeneric
                    {
                        status = true,
                        message = "Cuenta se encuentra aprobada."
                    };
                }
                else if (response.Id_Status == 1)
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "Cuenta se encuentra en espera de aprobación."
                    };
                }
                else if(response.Id_Status == 3)
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "Cuenta se encuentra rechazada."
                    };
                }
                else if (response.Id_Status == 4)
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "Cuenta se encuentra deshabilitada."
                    };
                }
                else
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "Creedenciales incorrectas"
                    };
                }


            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }



        }


        //Crear reporte
        public async Task<responseGeneric> report(requestReport request)
        {
            try
            {

                var sql = @"insert into report (id_neighborhood_board, rut, title, description, image_path, id_status, id_type_user)
                            values (@id_neighborhood_board, @rut, @title, @description, @image_path, @id_status, @id_type_user)";

                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    rut = request.rut,
                    title = request.title,
                    description = request.description,
                    image_path = request.image_path,
                    id_status = 1,
                    id_type_user = 3
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    try
                    {
                        var dashboardData = await _dashboardService.GetDashboardData(request.id_neighborhood_board);

                        // Enviar los datos actualizados al frontend
                        await _hubContext.Clients.All.SendAsync("ReceiveDashboardData", dashboardData);

                        Console.WriteLine("Datos del dashboard enviados al frontend.");
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"Error enviando datos del dashboard: {ex.Message}");
                    }

                    return new responseGeneric
                    {
                        status = true,
                        message = "reporte ingresado correctamente"
                    };
                }
                else
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "reporte no ingresado"
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        //Obtener las juntas de vecinos 
        public async Task<List<neighborhoodBoard>> listNeighborhoodBoard()
        {
            try
            {
                var sql = @"select id_neighborhood_board, name, email, cellphone  
                              from neighborhood_board
                             where enabled = true";



                var response = (await _dbConnection.QueryAsync<neighborhoodBoard>(sql)).ToList();

                return response;

            }
            catch (Exception ex)

            {
                return new List<neighborhoodBoard>();
            }



        }



        //Crear usuario 
        public async Task<responseGeneric> createUser(Users request)
        {

            try
            {

                var sqlCorreo = @"select Email from users where email = @email";
                var parametersCorreo = new { email = request.Email };
                string responseCorreo = "";

                responseCorreo = await _dbConnection.QueryFirstOrDefaultAsync<string>(sqlCorreo, parametersCorreo);

                if (responseCorreo != null & responseCorreo != "") 
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = $"Existe una cuenta con ese correo"
                    };
                }

                var sqlRut = @"select rut from users where rut = @rut";
                var parametersRut = new { rut = request.Rut };
                string responseRut = "";

                responseRut = await _dbConnection.QueryFirstOrDefaultAsync<string>(sqlRut, parametersRut);

                if (responseRut != null & responseRut != "")
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = $"Existe una cuenta con ese RUT"
                    };
                }



                var sqlUsers = @"insert into users (Rut, First_Name, Second_Name, First_Surname, Second_Surname, Birthdate, Email, Password, Address, Address_Verification_Url, Cellphone)
                                values (@Rut, @First_Name, @Second_Name, @First_Surname, @Second_Surname, @Birthdate, @Email, @Password, @Address, @Address_Verification_Url, @Cellphone)";

                var parameters = new
                {
                    Rut = request.Rut,
                    First_Name = request.First_Name,
                    Second_Name = request.Second_Name,
                    First_Surname = request.First_Surname,
                    Second_Surname = request.Second_Surname,
                    Birthdate = request.Birthdate,
                    Email = request.Email,
                    Password = request.Password,
                    Address = request.Address,
                    Address_Verification_Url = request.Address_Verification_Url,
                    Cellphone = request.Cellphone
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sqlUsers, parameters);

                if (rowsAffected > 0)
                {
                    var sqlNeighboorhood = @"insert into user_neighborhood_board (Id_Neighborhood_Board, Rut, Emergency_enabled, Creation_Date, Enabled, Id_Status, Id_Type_User)
                                values (@Id_Neighborhood_Board, @Rut, @Emergency_enabled, @Creation_Date, @Enabled, @Id_Status, @Id_Type_User)";

                    var parametersNeighborhood = new
                    {
                        Id_Neighborhood_Board = request.Id_Neighborhood_Board,
                        Rut = request.Rut,
                        Emergency_enabled = request.Emergency_enabled,
                        Creation_Date = request.Creation_Date,
                        Enabled = request.Enabled,
                        Id_Status = request.Id_Status,
                        Id_Type_User = request.Id_Type_User
                    };

                    var rowsAffectedNeighborhood = await _dbConnection.ExecuteAsync(sqlNeighboorhood, parametersNeighborhood);

                    if (rowsAffected > 0)
                    {
                        
                        try
                        {
                            var dashboardData = await _dashboardService.GetDashboardData(request.Id_Neighborhood_Board);

                            // Enviar los datos actualizados al frontend
                            await _hubContext.Clients.All.SendAsync("ReceiveDashboardData", dashboardData);

                            Console.WriteLine("Datos del dashboard enviados al frontend.");
                        }
                        catch (Exception ex)
                        {
                            Console.Error.WriteLine($"Error enviando datos del dashboard: {ex.Message}");
                        }


                        return new responseGeneric
                        {
                            status = true,
                            message = "usuario creado correctamente"
                        };
                    }
                    else
                    {
                        return new responseGeneric
                        {
                            status = true,
                            message = "usuario no creado"
                        };
                    }
                }
                else
                {
                    return new responseGeneric
                    {
                        status = true,
                        message = "usuario no creado"
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }

        }


        //Obtener las  categorias de emergencias 
        public async Task<List<emergencyCategoryList>> listEmergencyCategory(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select id_category, category 
                              from emergency_category
                             where id_neighborhood_board = @id_neighborhood_board";


                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var response = (await _dbConnection.QueryAsync<emergencyCategoryList>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)

            {
                return new List<emergencyCategoryList>();
            }



        }

        //Obtener los reportes

        public async Task<List<reports>> getReports(int id_neighborhood_board)
        {
            try
            {
                var db = _redis.GetDatabase();
                var reportsJson = await db.StringGetAsync($"report:{id_neighborhood_board}");

                if (reportsJson.IsNullOrEmpty)
                {
                    return new List<reports>();
                }

                var reportsList = System.Text.Json.JsonSerializer.Deserialize<List<reports>>(reportsJson);

                return new List<reports>(reportsList);
            }
            catch (Exception ex)
            {
                return new List<reports>();
            }
        }

        //Generar una emergencia 
        public async Task<responseGeneric> emergency(emergencyRequest emergency)
        {
            try
            {
                var parameters = new emergency
                {
                    id_neighborhood_board_user = emergency.id_neighborhood,
                    id_neighborhood_board_category = emergency.id_neighborhood,
                    id_category = emergency.id_category,
                    rut = emergency.rut,
                    address = emergency.address,
                    description = emergency.description,
                    latitude = emergency.latitude,
                    longitude = emergency.longitude,
                };

                var sql = @"insert into emergency (id_neighborhood_board_user, id_neighborhood_board_category, id_category, rut, address, description, latitude, longitude, id_type_user)
                            values (@id_neighborhood_board_user, @id_neighborhood_board_category, @id_category, @rut, @address, @description, @latitude, @longitude, @id_type_user)";

                var parametersDB = new
                {
                    id_neighborhood_board_user = parameters.id_neighborhood_board_user,
                    id_neighborhood_board_category = parameters.id_neighborhood_board_category,
                    id_category = parameters.id_category,
                    rut = parameters.rut,
                    address = parameters.address,
                    description = parameters.description,
                    latitude = parameters.latitude,
                    longitude = parameters.longitude,
                    id_type_user = 3
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parametersDB);

                if (rowsAffected > 0)
                {
                    try
                    {
                        var dashboardData = await _dashboardService.GetDashboardData(emergency.id_neighborhood);

                        // Enviar los datos actualizados al frontend
                        await _hubContext.Clients.All.SendAsync("ReceiveDashboardData", dashboardData);

                        Console.WriteLine("Datos del dashboard enviados al frontend.");
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"Error enviando datos del dashboard: {ex.Message}");
                    }

                    return new responseGeneric
                    {
                        status = true,
                        message = "emergencia ingresado correctamente"
                    };
                }
                else
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "emergencia no ingresado"
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        //Obtener la inforamción del usuario 
        public async Task<User> getUserInfo(string email)
        {
            try
            {
                var sql = @"select u.rut, u.first_name, u.second_name, u.first_surname, u.second_surname, u.birthdate, u.email, u.password, u.address, u.cellphone, n.id_neighborhood_board, n.emergency_enabled
                              from users u, user_neighborhood_board n 
                             where u.rut = n.rut
                               and u.email = @email
                               and n.enabled";

                var parameters = new { email = email };

                var response = await _dbConnection.QueryFirstOrDefaultAsync<User>(sql, parameters);

                return response;


            }
            catch (Exception ex)
            {
                return new User { };
            }



        }


        //Obtener las áreas comunes 
        public async Task<List<commonArea>> listCommonArea(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select c.id_common_area, c.name, c.addres, c.start_time, c.end_hours, m.number_hours
                            from common_area c, maximum_hours_common_area m
                            where c.id_neighborhood_board = m.id_neighborhood_board
                            and c.id_common_area = m.id_common_area
                            and c.id_neighborhood_board = @id_neighborhood_board";

                var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var response = (await _dbConnection.QueryAsync<commonArea>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)

            {
                return new List<commonArea>();
            }



        }

        //Excepción de días 
        //public async Task<List<reservations>> reservationsCommonArea(int id_neighborhood_board, int id_common_area)
        //{
        //    try
        //    {
        //        var redisKey = $"reservations:{id_neighborhood_board}:{id_common_area}";

        //        var redisDb = _redis.GetDatabase();

        //        // Intentamos obtener los datos de Redis
        //        var exceptionsJson = await redisDb.StringGetAsync(redisKey);

        //        // Si no hay datos en Redis, retornamos una lista vacía
        //        if (exceptionsJson.IsNullOrEmpty)
        //        {
        //            return new List<reservations>();
        //        }

        //        // Deserializamos los datos de JSON a una lista de exceptionOfDays
        //        var exceptionsList = JsonConvert.DeserializeObject<List<reservations>>(exceptionsJson);

        //        // Retornamos la lista de excepciones
        //        return exceptionsList;

        //    }
        //    catch (Exception ex)

        //    {
        //        return new List<reservations>();
        //    }
        //}

        //Fechas para reservar del área común 
        public async Task<List<commonAreaDate>> getCommonAreaDates(int id_neighborhood_board, int id_common_area)
        {
            try
            {
                var availableDates = new List<commonAreaDate>();

                var today = DateTime.Now.Date;

                // Generar los próximos 15 días (excluyendo hoy)
                var next15Days = Enumerable.Range(1, 15).Select(i => today.AddDays(i)).ToList();

                var query = @"SELECT date_exception 
                              FROM exception_of_days 
                              WHERE id_neighborhood_board = @id_neighborhood_board 
                              AND id_common_area = @id_common_area";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, id_common_area  = id_common_area };

                // Obtener las fechas de excepción
                var exceptionDates = (await _dbConnection.QueryAsync<DateTime>(query, parameters)).ToList();

                    // Filtrar las fechas, excluyendo las que están en la tabla de excepciones
                var filteredDates = next15Days.Where(date => !exceptionDates.Contains(date)).ToList();

                // Convertir las fechas filtradas a commonAreaDate y añadirlas a la lista de resultados
                foreach (var date in filteredDates)
                {
                    availableDates.Add(new commonAreaDate { available_day = date.ToString("yyyy-MM-dd") });
                }


                // Retornamos la lista de excepciones
                return availableDates;

            }
            catch (Exception ex)

            {
                return new List<commonAreaDate>();
            }
        }

        public async Task<List<commonAreaHours>> getCommonAreaHours(int id_neighborhood_board, int id_common_area, string date)
        {
            try
            {
                var availableHours = new List<commonAreaHours>();

                DateTime reservationDate = DateTime.Parse(date);

                var query = @"SELECT start_time, end_hours 
                FROM common_Area 
                WHERE id_neighborhood_board = @id_neighborhood_board 
                AND id_common_area = @id_common_area";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, id_common_area = id_common_area };

                // Obtener las fechas de excepción
                var commonArea = await _dbConnection.QueryFirstOrDefaultAsync<(TimeSpan start_time, TimeSpan end_hours)>(
                query, parameters);


                if (commonArea == default)
                {
                    return availableHours;
                }

                var reservationQuery = @"
                SELECT start_hour, end_hour 
                FROM reservation 
                WHERE id_neighborhood_board_common_area = @id_neighborhood_board
                AND id_common_area = @id_common_area
                AND date_reservation = @date::date
                AND enabled = true";


                var reservationParameters = new { id_neighborhood_board = id_neighborhood_board, id_common_area = id_common_area, date = date };

                var reservedHours = (await _dbConnection.QueryAsync<(TimeSpan start_hour, TimeSpan end_hour)>(
                reservationQuery, reservationParameters)).ToList();

                var startTime = commonArea.start_time;
                var endTime = commonArea.end_hours;


                // Filtrar las fechas, excluyendo las que están en la tabla de excepciones
                for (var time = startTime; time < endTime; time = time.Add(TimeSpan.FromHours(1)))
                {
                    // Verificar si la hora está en las reservas
                    bool isReserved = reservedHours.Any(r =>
                        (time >= r.start_hour && time < r.end_hour) || // Está dentro de un periodo reservado
                        (time.Add(TimeSpan.FromHours(1)) > r.start_hour && time.Add(TimeSpan.FromHours(1)) <= r.end_hour)); // Sobrelapamiento parcial

                    if (!isReserved)
                    {
                        availableHours.Add(new commonAreaHours
                        {
                            StartHour = time.ToString(@"hh\:mm"),
                            EndHour = time.Add(TimeSpan.FromHours(1)).ToString(@"hh\:mm")
                        });
                    }
                }

                // Retornamos la lista de excepciones
                return availableHours;

            }
            catch (Exception ex)

            {
                return new List<commonAreaHours>();
            }
        }


        //Realizar reserva 
        public async Task<responseGeneric> reservation(requestReservation request)
        {
            try
            {

                var sql = @"insert into reservation (id_neighborhood_board_common_area, id_neighborhood_board_user, id_type_user, id_common_area, rut, date_reservation, start_hour, end_hour, number_hours, enabled)
                            values (@id_neighborhood_board_common_area, @id_neighborhood_board_user, @id_type_user, @id_common_area, @rut, @date_reservation, @start_hour, @end_hour, @number_hours, @enabled)";

                var parametersDB = new
                {
                    id_neighborhood_board_common_area = request.id_neighborhood_board,
                    id_neighborhood_board_user = request.id_neighborhood_board,
                    id_type_user = 3,
                    id_common_area = request.id_common_area,
                    rut = request.rut,
                    date_reservation = request.date_reservation.ToDateTime(TimeOnly.MinValue),
                    start_hour = request.start_hour.ToTimeSpan(),
                    end_hour = request.end_hour.ToTimeSpan(),
                    number_hours = request.number_hours,
                    enabled = true
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parametersDB);

                if (rowsAffected > 0)
                {
                    // Reserva creada correctamente
                    // Ahora ejecutamos el procedimiento almacenado para obtener las horas disponibles
                    var sqlSP = "SELECT * FROM get_available_reservations(@id_common_area)";
                    var availableReservations = await _dbConnection.QueryAsync(sqlSP, new { id_common_area = request.id_common_area });

                    // Formateamos la clave para Redis
                    var redisKey = $"reservations:{request.id_neighborhood_board}:{request.id_common_area}";

                    // Serialización personalizada de los datos para usar el formato "YYYY-MM-DD" para available_day
                    var reservationsData = JsonConvert.SerializeObject(availableReservations, new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd", // Configuramos el formato de fecha para "available_day"
                        Formatting = Formatting.None
                    });

                    // Obtén la base de datos de Redis
                    var redisDb = _redis.GetDatabase();  // _redis es del tipo IConnectionMultiplexer

                    // Guardamos el resultado en Redis
                    await redisDb.StringSetAsync(redisKey, reservationsData);

                    // Retornamos una respuesta exitosa
                    return new responseGeneric
                    {
                        status = true,
                        message = "Reserva ingresada correctamente y actualizada en Redis."
                    };
                }
                else
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "Reserva no ingresada."
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        //Listar reservas 
        public async Task<List<reservation>> getReservations(int id_neighborhood_board_common_area, string rut)
        {
            try
            {
                var sql = @"select id_reservation,to_char(date_reservation, 'YYYY-MM-DD') as date_reservation, start_hour, end_hour, number_hours, enabled, id_common_area
                            from reservation 
                            where id_neighborhood_board_common_area = @id_neighborhood_board_common_area
                            and rut = @rut";

                var parameters = new { id_neighborhood_board_common_area = id_neighborhood_board_common_area, rut = rut };

                var response = (await _dbConnection.QueryAsync<reservation>(sql, parameters)).ToList();

                return response;

            }
            catch (Exception ex)

            {
                return new List<reservation>();
            }
        }

        //Deshabilitar reserva 
        public async Task<responseGeneric> updateReservation(requestUpdateReservation request)
        {
            try
            {

                var sql = @"update reservation 
                            set enabled = false 
                            where id_neighborhood_board_common_area = @id_neighborhood_board_common_area
                            and id_common_area = @id_common_area
                            and id_reservation = @id_reservation
                            and rut = @rut";

                var parametersDB = new
                {
                    id_neighborhood_board_common_area = request.id_neighborhood_board,
                    id_common_area = request.id_common_area,
                    id_reservation = request.id_reservation,
                    rut = request.rut
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parametersDB);

                if (rowsAffected > 0)
                {

                    // Reserva creada correctamente
                    // Ahora ejecutamos el procedimiento almacenado para obtener las horas disponibles
                    var sqlSP = "SELECT * FROM get_available_reservations(@id_common_area)";
                    var availableReservations = await _dbConnection.QueryAsync(sqlSP, new { id_common_area = request.id_common_area });

                    // Formateamos la clave para Redis
                    var redisKey = $"reservations:{request.id_neighborhood_board}:{request.id_common_area}";

                    // Serialización personalizada de los datos para usar el formato "YYYY-MM-DD" para available_day
                    var reservationsData = JsonConvert.SerializeObject(availableReservations, new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd", // Configuramos el formato de fecha para "available_day"
                        Formatting = Formatting.None
                    });

                    // Obtén la base de datos de Redis
                    var redisDb = _redis.GetDatabase();  // _redis es del tipo IConnectionMultiplexer

                    // Guardamos el resultado en Redis
                    await redisDb.StringSetAsync(redisKey, reservationsData);

                    // Retornamos una respuesta exitosa
                    return new responseGeneric
                    {
                        status = true,
                        message = "Reserva actualizada correctamente y actualizada en Redis."
                    };
                }
                else
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "reserva no actualizado"
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }

        //Obtener datos de la cuenta bancaria 
        public async Task<List<bankAccount>> getBankAccount(int id_neighborhood_board)
        {
            try
            {
                var sql = @"select * 
                            from bank_account
                            where id_neighborhood_board = @id_neighborhood_board";
                
                 var parameters = new { id_neighborhood_board = id_neighborhood_board };

                var response = (await _dbConnection.QueryAsync<bankAccount>(sql, parameters)).ToList();

                return response;


            }
            catch (Exception ex)
            {
                return new List<bankAccount> { };
            }



        }

        //Crear certificado 
        public async Task<responseGeneric> certificate(requestCertificate request)
        {
            try
            {

                var sql = @"insert into certificate (id_neighborhood_board, rut, id_type_user, evidence_image_path, request_day, id_status, evidence_pay_path, cellphone, addres)
                            values (@id_neighborhood_board, @rut, @id_type_user, @evidence_image_path, @request_day, @id_status, @evidence_pay_path, @cellphone, @addres)";

                var parameters = new
                {
                    id_neighborhood_board = request.id_neighborhood_board,
                    rut = request.rut,
                    evidence_image_path = request.evidence_addres_path,
                    request_day = DateTime.Now,
                    evidence_pay_path = request.evidence_pay_path,
                    id_status = 1,
                    id_type_user = 3, 
                    cellphone = request.cellphone,
                    addres = request.addres
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    return new responseGeneric
                    {
                        status = true,
                        message = "reporte ingresado correctamente"
                    };
                }
                else
                {
                    return new responseGeneric
                    {
                        status = false,
                        message = "reporte no ingresado"
                    };
                }

            }
            catch (Exception ex)
            {
                return new responseGeneric
                {
                    status = false,
                    message = $"An error occurred: {ex.Message}"
                };
            }
        }


        public async Task<responseGeneric> sendEmergency(int id_neighborhood_board, int id_category, string adress, string description, string latitude, string longitude)
        {
            try
            {

                var url = Environment.GetEnvironmentVariable("URL_WHATSAPP");
                var username = Environment.GetEnvironmentVariable("BASIC_AUTH_USERNAME");
                var password = Environment.GetEnvironmentVariable("BASIC_AUTH_PASSWORD");
                var mapsUrl = $"https://www.google.com/maps/search/?api=1&query={latitude},{longitude}";

                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));

                var sql = @"SELECT category FROM emergency_category
                    WHERE id_neighborhood_board = @id_neighborhood_board 
                    AND id_category = @id_category";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, id_category = id_category };



                // Usar 'using' para asegurarse de que la conexión se cierre correctamente
                using (var connection = new NpgsqlConnection(Environment.GetEnvironmentVariable("DATABASE_CONNECTION_STRING")))
                {
                    await connection.OpenAsync();
                    var category = await connection.QueryFirstOrDefaultAsync<string>(sql, parameters);

                    var sqlPhone = @"select cellphone 
                             from users u, user_neighborhood_board n
                             where u.rut = n.rut 
                             and id_neighborhood_board = @id_neighborhood_board
                             and enabled = true";

                    var parametersPhone = new { id_neighborhood_board = id_neighborhood_board };
                    var cellphones = (await connection.QueryAsync<string>(sqlPhone, parametersPhone)).ToList();

                    foreach (var phone in cellphones)
                    {
                        using (var httpClient = new HttpClient())
                        {
                            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                            var postData = new
                            {
                                number = phone,
                                message = $@"Emergencia: {category} reportada en {adress}. 
Descripción: {description}. 
Ver en el mapa: 
{mapsUrl}"
                            };

                            var jsonContent = new StringContent(System.Text.Json.JsonSerializer.Serialize(postData), Encoding.UTF8, "application/json");
                            var response = await httpClient.PostAsync(url, jsonContent);

                            if (!response.IsSuccessStatusCode)
                            {
                                throw new Exception($"Error al enviar mensaje a {phone}: {response.ReasonPhrase}");
                            }
                        }
                    }

                   

                    return new responseGeneric { status = true, message = "Mensajes enviados correctamente." };
                }
            }
            catch (Exception ex)
            {
                return new responseGeneric { status = false, message = $"An error occurred: {ex.Message}" };
            }
        }


        public async Task<List<emergencyUserResponse>> getEmergencyUser(int id_neighborhood_board, string rut)
        {
            try
            {
                var sql = @"select e.id_emergency, e.id_category, e.address, e.description, 
                            e.latitude, e.longitude, e.date_emergency, ca.category 
                            from emergency e, emergency_category ca
                            where e.id_category = ca.id_category 
                            and e.id_neighborhood_board_user = ca.id_neighborhood_board
                            and e.id_neighborhood_board_category = ca.id_neighborhood_board
                            and e.rut = @rut
                            and e.id_neighborhood_board_category = @id_neighborhood_board
                            order by e.date_emergency desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, rut = rut  };

                var emergencyList = (await _dbConnection.QueryAsync<emergencyUserDB>(sql, parameters)).ToList();


                var responseList = emergencyList.Select(e => new emergencyUserResponse
                {
                    category = e.category,
                    address = e.address,
                    description = e.description,
                    googleMaps = $"https://www.google.com/maps/search/?api=1&query={e.latitude},{e.longitude}",
                    date_emergency = e.date_emergency
                }).ToList();


                return responseList;
            }
            catch (Exception ex)
            {
                return new List<emergencyUserResponse>();
            }
        }

        public async Task<List<reportUserResponse>> getReportsUser(int id_neighborhood_board, string rut)
        {
            try
            {
                var url = Environment.GetEnvironmentVariable("API_BASE_URL");

                var sql = @"select r.title, r.description, r.image_path,  s.status
                            from report r, status s 
                            where r.id_status = s.id_status
                            and rut = @rut
                            and id_neighborhood_board = @id_neighborhood_board
                            order by date_report desc";

                var parameters = new { id_neighborhood_board = id_neighborhood_board, rut = rut };

                var emergencyList = (await _dbConnection.QueryAsync<reportUserDB>(sql, parameters)).ToList();


                var responseList = emergencyList.Select(e => new reportUserResponse
                {
                    title = e.title,
                    description = e.description,
                    status = e.status,
                    url_image = string.IsNullOrWhiteSpace(e.image_path) ? "" : $"{url}{e.image_path}"
                }).ToList();


                return responseList;
            }
            catch (Exception ex)
            {
                return new List<reportUserResponse>();
            }
        }


    }
}
