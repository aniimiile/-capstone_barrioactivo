using api_core.Services;
using DotNetEnv;
using Microsoft.OpenApi.Models;
using static api_core.Security.ApiKeyAuthAttribute;
using NLog;
using NLog.Web;
using Npgsql;
using System.Data;
using Microsoft.AspNetCore.Http.Features;
using StackExchange.Redis;
using api_core.Converts;
using DinkToPdf.Contracts;
using DinkToPdf;
using api_core.Hubs;

var logger = NLog.LogManager.Setup().LoadConfigurationFromFile("nlog.config").GetCurrentClassLogger();

var builder = WebApplication.CreateBuilder(args);

// Cargar las variables del archivo .env
Env.Load();

var redisHost = Environment.GetEnvironmentVariable("REDIS_HOST");
var redisPort = Environment.GetEnvironmentVariable("REDIS_PORT");

var redisConnectionString = $"{redisHost}:{redisPort}";

// Obtener la clave API desde el archivo .env
var apiKey = Environment.GetEnvironmentVariable("API_KEY");

// Add services to the container.

builder.Logging.ClearProviders();  // Eliminar otros proveedores de logging
builder.Host.UseNLog();

builder.Services.AddSingleton<IConnectionMultiplexer>(ConnectionMultiplexer.Connect(redisConnectionString));
builder.Services.AddScoped<IDbConnection>(sp =>
    new NpgsqlConnection(Environment.GetEnvironmentVariable("DATABASE_CONNECTION_STRING")));


builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.Converters.Add(new DateOnlyJsonConverter()); // Registrar DateOnly
        options.JsonSerializerOptions.Converters.Add(new TimeOnlyJsonConverter()); // Registrar TimeOnly
    });
builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 104857600; // 100 MB para archivos
});

builder.Services.AddHttpClient<faceValidationService>();
builder.Services.AddSingleton<IConverter, SynchronizedConverter>(provider => new SynchronizedConverter(new PdfTools()));


builder.Services.AddScoped<appService>();
builder.Services.AddScoped<admService>();
builder.Services.AddTransient<dashboardService>();
builder.Services.AddScoped<PdfGeneratorService>();
builder.Services.AddSignalR();

// Configuraci�n de CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddSwaggerGen(c =>
{
    c.AddSecurityDefinition("ApiKey", new OpenApiSecurityScheme()
    {
        In = ParameterLocation.Header,
        Description = "ApiKey authorization",
        Name = "ApiKey",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Basic"
    });

    c.OperationFilter<AuthResponsesOperationFilter>();
});

var app = builder.Build();

app.UseStaticFiles();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

// Habilitar CORS
app.UseCors("AllowAll");

app.UseAuthorization();

app.MapHub<dashboardHub>("/dashboardHub");
app.MapControllers();

app.Run();
