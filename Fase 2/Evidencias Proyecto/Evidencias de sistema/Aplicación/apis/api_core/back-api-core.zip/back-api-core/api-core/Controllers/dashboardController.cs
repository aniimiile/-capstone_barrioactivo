﻿using api_core.Hubs;
using api_core.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace api_core.Controllers
{

    [ApiController]
    [Route("[controller]")]

    public class dashboardController : ControllerBase
    {
        private readonly dashboardService _service;
        private readonly IHubContext<dashboardHub> _hubContext;

        public dashboardController(dashboardService service, IHubContext<dashboardHub> hubContext)
        {
            _service = service;
            _hubContext = hubContext;
        }

        [HttpGet("get")]
        public async Task<IActionResult> GetDashboardData(int neighborhoodId)
        {
            var emergencies = await _service.GetEmergencyData(neighborhoodId);
            var reports = await _service.GetReportData(neighborhoodId);
            var users = await _service.GetUserStatusData(neighborhoodId);

            return Ok(new
            {
                Emergencies = emergencies,
                Reports = reports,
                Users = users
            });
        }

        [HttpPost("notify")]
        public async Task<IActionResult> NotifyClients([FromBody] string message)
        {
            await _hubContext.Clients.All.SendAsync("ReceiveUpdate", message);
            return Ok(new { Status = "Notification sent" });
        }
    }
}
